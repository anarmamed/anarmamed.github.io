<?php
$wicon_archive_layout = get_theme_mod('archive_layouts', 'right');

$sidebar_archive_class = '';
$col_archive_class = array();

if ($wicon_archive_layout === 'full') :
    $col_archive_class[] = 'col-md-12 ';
else :
    if(!is_active_sidebar('sidebar-1')):
        $col_archive_class[] = 'col-md-12 ';
    else :
        $col_archive_class[] = 'col-md-9 ';
    endif;

endif;
if ($wicon_archive_layout === 'left' && is_active_sidebar('sidebar-1')) :
    $col_archive_class[] = 'col-md-push-3 ';
    $sidebar_archive_class = 'col-md-pull-9';
endif;
?>
<div class="vk-banner vk-background-image-3">
    <div class="vk-background-overlay vk-background-black-1 _80"></div>
    <div class="container wrapper">
        <div class="page-heading">
            <h1 class="page-title"><?php the_archive_title(); ?></h1>
        </div>
    </div>
</div>


<div class="vk-breadcrumb">
    <nav class="container">
        <div class="row">
            <?php get_template_part('template-parts/breadcrumbs'); ?>
        </div>
    </nav>
</div>

<div class="vk-blog-wrapper vk-blog-list">
    <div class="container">
        <div class="row">
            <div class="blog-list clearfix">
                <div class="<?php echo esc_attr(implode(' ', $col_archive_class)); ?>">
                    <div class="blog-content">
                        <?php
                        while (have_posts()) : the_post();
                            ?>
                            <div class="content-box">
                                <?php if( has_post_thumbnail( ) ) : ?>
                                    <div class="vk-img-frame">
                                        <a class="vk-img" href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail(); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                <h2 class="vk-text-uppercase wicon-txt-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                <div class="info">
                                    <ul class="vk-list">
                                        <li class="vk-text-capitalize"><?php echo esc_html__('Categories:','wicon'); ?><span><?php the_category(); ?></span></li>
                                        <li class="vk-text-capitalize"><?php echo esc_html__('date:','wicon'); ?> <span><?php echo get_the_date(); ?> </span></li>
                                    </ul>
                                </div>
                                <div class="content">
                                    <?php the_excerpt(); ?>
                                    <div class="vk-buttons">
                                        <a href="<?php the_permalink(); ?>" class="vk-btn vk-btn-transparent vk-btn-readmore text-uppercase">
                                            <?php echo esc_html__('read more','wicon'); ?>
                                            <i class="fa fa-long-arrow-right vk-text-right"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="vk-divider"></div>
                            </div>
                        <?php
                        endwhile;
                        ?>
                        <!-- PAGE NUMBER -->
                        <nav class="box-pagination vk-text-right">
                            <ul class="vk-pagination">
                                <?php echo wicon_get_pagination_links(); ?>
                            </ul>
                        </nav>
                    </div>
                </div>
                <?php if ($wicon_archive_layout !== 'full' && is_active_sidebar('sidebar-1')) : ?>
                <div class="col-md-3 <?php echo esc_attr($sidebar_archive_class); ?>">
                    <?php get_sidebar(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <!------ END BLOG WRAPPER ------>
    </div>

</div>