jQuery(document).ready(function($) {
	setTimeout(function() {
		var url = window.location.href;
		if (url.indexOf('page=tgmpa-install-plugins&plugin=univercore&tgmpa-activate=activate-plugin')>= 0) {
			window.location.href = object_merlin.import_merlin_url;
		}
	}, 1000);
});