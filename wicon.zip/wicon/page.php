<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wicon
 */
$hidden_page_title = get_post_meta($post->ID, 'meta_hidden_page_title', true);
$page_title_bg_img = get_post_meta($post->ID, 'page_title_bg_img', true);
 
$stylein = '';
if(isset($page_title_bg_img) && $page_title_bg_img !=''){
    $stylein = 'style="background-image: url('.esc_url($page_title_bg_img).');background-repeat: no-repeat;"'; 
}

get_header();
?>
    <section class="vk-content">
        <?php if (!is_page('homepage') && !is_front_page() && !is_home() && !is_page('home-dark') && !is_page('home-default') && !is_page('home-left-menu') && !is_page('home-one-page') && !is_page('home-shop') && !is_page('home-slider') && $hidden_page_title !== 'yes' ): ?>
            <div class="vk-banner vk-background-image-3" <?php echo $stylein; ?>>
                <div class="vk-background-overlay vk-background-black-1 _80"></div>
                <div class="container wrapper">
                    <div class="page-heading">
                        <?php the_title('<h1 class="page-title">', '</h1>'); ?>
                    </div>
                </div>
            </div>
            <!--./vk-banner-->
            <div class="vk-breadcrumb">
                <nav class="container">
                    <?php get_template_part('template-parts/breadcrumbs'); ?>
                </nav>
            </div>
        <?php endif; ?>
        <div class="vk-page <?php echo wicon_class_active_sidebar(); ?>">
            <?php
            while (have_posts()) : the_post();

                get_template_part('template-parts/content', 'page');

            endwhile; // End of the loop.
            ?>
        </div><!-- #primary -->
    </section>
<?php
get_footer();
