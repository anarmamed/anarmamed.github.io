<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="vk-blog-wrapper">
        <!------ BEGIN BLOG WRPPER ------>
        <div class="single-blog">
            <div class="blog-content">
                <?php if (has_post_thumbnail()) : ?>
                    <div class="vk-img-frame">
                        <?php the_post_thumbnail(); ?>
                    </div>
                <?php endif; ?>

                <?php if (!is_single()) : ?>
                    <h2 class="blog-single-title vk-text-uppercase"><?php the_title(); ?></h2>
                <?php endif; ?>

                <div class="info">
                    <ul class="vk-list">
                        <li class="vk-text-capitalize"><?php echo esc_html__('Categories:', 'wicon'); ?>
                            <span><?php the_category(); ?> </span></li>
                        <li class="vk-text-capitalize"><?php echo esc_html__('date', 'wicon'); ?>:
                            <span><?php echo get_the_date(); ?> </span></li>
                        <li class="vk-text-capitalize"><?php echo esc_html__('comments:', 'wicon'); ?>
                            <p><?php comments_number('0', '1', '%'); ?></p>
                        </li>
                    </ul>
                </div>
                <div class="content">
                    <?php the_content(); ?>
                    <?php
                    wp_link_pages(array(
                            'link_before' => '<span>',
                            'link_after' => '</span>',
                            'pagelink' => '%',
                            'before' => '<div class="blog-pagination">',
                            'after' => '</div>',
                            'nextpagelink' => esc_html__('&rarr;', 'wicon'),
                            'previouspagelink' => esc_html__('&larr;', 'wicon'),
                        )
                    ); ?>
                </div>
                <?php if (function_exists('wicon_social_share')) :
                    wicon_social_share();
                endif; ?>
                <?php
                if ((!empty(get_the_tags()))) :
                    ?>
                    <div class="tag">
                        <ul>
                            <li><h5 class="vk-text-uppercase title"><?php echo esc_html__('tags', 'wicon'); ?></h5></li>
                            <?php
                            the_tags('<li class="vk-tag">', '</li><li class="vk-tag">', '</li>');
                            ?>
                        </ul>
                    </div>
                    <?php
                endif;
                ?>
                <?php
                if (comments_open() || get_comments_number()) :
                    comments_template();
                endif;
                ?>
            </div>
        </div>
        <!------ END BLOG WRAPPER ------>
    </div>
</article>