<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package wicon
 */

get_header(); ?>
    <section id="primary" class="content-area <?php echo wicon_class_active_sidebar(); ?>">
        <main id="main" class="site-main">
            <?php
            get_template_part('template-parts/main/search/page', 'search');
            ?>
        </main><!-- #main -->
    </section><!-- #primary -->

<?php
get_footer();


?>