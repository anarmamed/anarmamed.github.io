<?php
$htrans_class = 'vk-header-transparent';
if (is_object($post) && get_post_meta($post->ID, 'meta-header1-trans', true) === "no") :
    $htrans_class = 'vk-header-relative';
endif;
?>
<div class="animsition main-wrapper">
    <header class="vk-header <?php echo esc_attr($htrans_class); ?> vk-header-home vk-header1">
        <nav class="vk-navbar  navbar">
            <div class="container">
                <div class="vk-navbar-header navbar-header row">
                        <button type="button" class="navbar-toggle vk-navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
                            <i class="toggle-icon"></i>
                        </button>                        
                        <?php 
                        if(get_theme_mod('display_cart', true)){
                            if ( class_exists( 'WooCommerce' ) ) : ?>
                                <div class="shopping-cart hidden-md hidden-lg">
                                    <i class="fa fa-shopping-basket" data-toggle="collapse"
                                       data-target="#shopping-cart-list"></i>
                                    <span class="number-item">
                                    <?php global $woocommerce; ?>
                                    <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                                    </span>
                                </div>
                        <?php 
                            endif; 
                        }
                        ?>                      

                        <a class="vk-navbar-brand navbar-brand <?php if (empty(get_theme_mod('logo_mobile'))) : echo 'empty-logo-mobile'; endif; ?>" href="<?php echo esc_url(home_url('/')); ?>">
                            <?php if (!empty(get_theme_mod('logo_header1_style1'))) : ?>
                                <img src="<?php echo esc_url(get_theme_mod('logo_header1_style1')); ?>" alt="<?php esc_attr_e('logo', 'wicon') ?>" class="logo">
                            <?php else: ?>
                                <svg version="1.1" id="wicon-logo-svg" xmlns="http://www.w3.org/2000/svg"
                                     xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                     width="290.037px" height="290.25px" viewBox="0 0 290.037 290.25"
                                     enable-background="new 0 0 290.037 290.25"
                                     xml:space="preserve">
                        <polygon fill="#FFC000"
                                 points="170,60.25 50,60.25 0,60.25 0,110.25 0,290.25 50,290.25 50,110.25 170,110.25 "/>
                                    <polygon fill="#FFC000" points="60.038,120.25 60.038,240.25 60.038,290.25 110.038,290.25 290.037,290.25 290.037,240.25
110.038,240.25 110.038,120.25 "/>
                                    <polygon fill="#FFC000"
                                             points="120.019,230 240.019,230 290.019,230 290.019,180 290.019,0 240.019,0 240.019,180 120.019,180 "/>
                                    <polygon fill="#FFC000"
                                             points="229.98,170 229.98,50 229.98,0 179.98,0 -0.019,0 -0.019,50 179.98,50 179.98,170 "/>
                    </svg>
                                <span class="logo-text text-uppercase"><?php echo esc_html__('WICON', 'wicon') ?></span>
                            <?php endif; ?>
                            <?php
                            if (!empty(get_theme_mod('logo_mobile'))) :
                                ?>
                                <img src="<?php echo esc_url(get_theme_mod('logo_mobile')); ?>" alt="<?php esc_attr_e('logo', 'wicon') ?>" class="logo-mobile">
                                <?php
                            endif;
                            ?>

                        </a>
                        
                        <?php 
                        if(get_theme_mod('display_cart', true)){
                        if ( class_exists( 'WooCommerce' ) ) : ?>
                            <div class="shopping-cart-list collapse" id="shopping-cart-list">
                                <div class="vk-table woo-mini-cart">
                                    <ul class="vk-table-row">
                                        <li class="vk-table-data"><?php echo esc_html__('product', 'wicon'); ?></li>
                                    </ul>
                                    <?php
                                    if ( function_exists( 'woocommerce_mini_cart' ) ) :
                                        woocommerce_mini_cart();
                                    endif;
                                    ?>
                                </div>
                            </div>
                            
                        <?php endif; 
                        }
                        ?>
                    </div>

                <div class="collapse navbar-collapse vk-navbar-collapse" id="menu">
                        <?php
                        wp_nav_menu(
                            array(
                                'theme_location' => 'primary',
                                'container' => 'ul',
                                'menu_class' => 'vk-navbar-nav navbar-right',
                                'echo' => true,
                            )
                        );
                        ?>
                        <?php
                        if(get_theme_mod('display_search', true)){ ?>
                        <div class="box-search-header collapse" id="box-search-header">
                            <div class="vk-input-group">
                                <?php get_search_form(); ?>
                                <button class="vk-btn btn-search"><i class="fa fa-search"></i></button>
                            </div>
                        </div>                        
                        <?php } ?>
                    </div>

            </div>
            <!--./container-->
        </nav>
        <!--./vk-navbar-->
        <div class="vk-header-top hidden-xs hidden-sm">
            <div class="container">
                <div class="content">
                    <?php 
                    if(get_theme_mod('display_cart', true)){
                    if ( class_exists( 'WooCommerce' ) ) : ?>
                        <div class="shopping-cart">
                            <i class="fa fa-shopping-basket" data-toggle="collapse" data-target="#shopping-cart-list"></i>
                            <?php global $woocommerce; ?>
                            <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                        </div>
                    <?php endif; 
                    }
                    ?>
                    <ul class="quick-address">
                        <?php if (!empty(get_theme_mod('phone_header'))) :
                            echo '<li>'.esc_html(get_theme_mod('phone_header')).'</li>';
                        endif;

                        if (!empty(get_theme_mod('email_header'))) :
                        echo '<li>'.esc_html(get_theme_mod('email_header')).'</li>';
                        endif;

                        if (!empty(get_theme_mod('time_header'))) :
                            echo '<li>'.esc_html(get_theme_mod('time_header')).'</li>';
                        endif; ?>
                    </ul>
                </div>
            </div>
        </div>        
    </header>
    <!--./vk-header-->
