<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wicon
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="<?php echo set_url_scheme('//gmpg.org/xfn/11'); ?>">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
//get_template_part('template-parts/main/loader/loader');

if (class_exists('Univercore')):
    if (!is_search()) :
        if (!is_404()) :
            if (is_object($post) && get_post_meta($post->ID, 'custom-header', true) === "Header 2" or get_theme_mod('layout_header') === 'header2') :
                ?>
                <div class="fix-full">
                    <div class="col-md-2 row">
                        <?php
                        get_template_part('template-parts/main/header/header', 'v2');
                        ?>
                    </div>
                </div>
                </div>
                <?php
            endif;
        endif;
    endif;
    ?>
    <div id="page" class="site <?php if (is_object($post) && get_post_meta($post->ID, 'custom-header', true) == "Header 2") : echo "col-md-12"; endif; ?>">
    <?php
    $meta_page_header_style = '';
    if (is_page()) :
        global $post;
        $meta_page_header_style = get_post_meta($post->ID, 'custom-header', true);
    endif;

    $header_layout = get_theme_mod('layout_header', 'header1');



    if (is_page() && $meta_page_header_style !== '' && $meta_page_header_style !== 'Default') :
        switch ($meta_page_header_style) {
            case 'Header 1':
                  get_template_part('template-parts/main/header/header', 'v1');
            break;
            case 'Header 2':
                get_template_part('template-parts/main/header/header', 'v2');
                break;
            case 'Header 3':
                get_template_part('template-parts/main/header/header', 'v3');
                break;
            case 'Header 4':
                get_template_part('template-parts/main/header/header', 'v4');
                break;
            case 'Header 5':
                get_template_part('template-parts/main/header/header', 'v5');
                break;

            case 'builder':
                get_template_part('template-parts/main/header/header', 'builder');
                break;
            case 'luxury':
                get_template_part('template-parts/main/header/header', 'luxury');
                break;

        }

    else:

        switch ($header_layout) {
            case 'header1':
                get_template_part('template-parts/main/header/header', 'v1');
                break;
            case 'header2':
                get_template_part('template-parts/main/header/header', 'v2');
                break;
            case 'header3':
                get_template_part('template-parts/main/header/header', 'v3');
                break;
            case 'header4':
                get_template_part('template-parts/main/header/header', 'v4');
                break;
            case 'header5':
                get_template_part('template-parts/main/header/header', 'v5');
                break;

            case 'builder':
                get_template_part('template-parts/main/header/header', 'builder');
                break;
            case 'luxury':
                get_template_part('template-parts/main/header/header', 'luxury');
                break;
        }
    endif;

else:
    ?>
    <header id="masthead" class="site-header  wh-default ">
            <div class="container">
                <div class="site-branding">
                    <?php
                    if (is_object($post) && !empty(get_post_meta($post->ID, 'custom-header', true))) :
                        the_custom_logo();
                    else :
                    ?>
                        <a class="logo-empty vk-navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                            <svg version="1.1" id="wicon-logo-svg" xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                 width="290.037px" height="290.25px" viewBox="0 0 290.037 290.25"
                                 enable-background="new 0 0 290.037 290.25"
                                 xml:space="preserve">
                        <polygon fill="#FFC000"
                                 points="170,60.25 50,60.25 0,60.25 0,110.25 0,290.25 50,290.25 50,110.25 170,110.25 "/>
                                <polygon fill="#FFC000" points="60.038,120.25 60.038,240.25 60.038,290.25 110.038,290.25 290.037,290.25 290.037,240.25
110.038,240.25 110.038,120.25 "/>
                                <polygon fill="#FFC000"
                                         points="120.019,230 240.019,230 290.019,230 290.019,180 290.019,0 240.019,0 240.019,180 120.019,180 "/>
                                <polygon fill="#FFC000"
                                         points="229.98,170 229.98,50 229.98,0 179.98,0 -0.019,0 -0.019,50 179.98,50 179.98,170 "/>
                    </svg>
                            <span class="logo-text text-uppercase"><?php echo esc_html__('WICON', 'wicon') ?></span>
                        </a>
                        <?php
                    endif;
                    if (is_front_page() && is_home()) : ?>
                        <h1 class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a></h1>
                    <?php else : ?>
                        <p class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a></p>
                    <?php
                    endif;
                    $description = get_bloginfo('description', 'display');
                    if ($description || is_customize_preview()) :
                        echo '<p class="site-description">'.esc_attr($description).'</p>';
                    endif; ?>
                </div><!-- .site-branding -->
                <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e('Primary Menu', 'wicon'); ?></button>
                <nav id="site-navigation" class="main-navigation">
                    <?php
                    if (has_nav_menu('primary')) : ?>
                        <div class="wicon-site-header-menu">
                            <?php wp_nav_menu(array('theme_location' => 'primary', 'menu_id' => 'primary-menu')); ?>
                        </div>
                    <?php else :
                        $admin_url = esc_url(get_admin_url()) . 'customize.php?url=' . esc_url(get_permalink()) . '&autofocus%5Bsection%5D=menu_locations';
                        echo '<div class="txt-assign-menu col-sm-5 col-sp-6 col-md-4 col-lg-10"><a href="' . esc_url($admin_url) . '">' . esc_html__('Assign a menu here', 'wicon') . '</a></div>';
                    endif; ?>
                </nav><!-- #site-navigation -->
            </div>
        </header><!-- #masthead -->
    <?php
endif;
?>
    <div id="content" class="site-content <?php if (class_exists('Univercore')) : echo "viki-single-fix"; endif; ?>">
