<header class="page-header">
    <div class="vk-banner vk-background-image-3">
        <div class="vk-background-overlay vk-background-black-1 _80"></div>
        <div class="container wrapper">
            <div class="page-heading">
                <h1 class="page-title"><?php echo esc_html__('search', 'wicon'); ?></h1>
            </div>
        </div>
    </div>
</header><!-- .page-header -->
<div class="vk-blog-wrapper vk-blog-list">
    <!------ BEGIN BLOG WRPPER ------>
    <div class="container">
        <div class="row">
            <div class="blog-list clearfix">
                <?php if (is_active_sidebar('sidebar-1')) :
                    echo '<div class="col-md-9">';
                else :
                    echo '<div class="col-md-12">';
                endif; ?>
                    <div class="blog-content">
                        <h4 class="results-title"><?php printf(esc_html__('Search Results for : %s', 'wicon'), ' "<span>' . get_search_query() . '</span>"'); ?></h4>
                        <?php
                        if (have_posts()) :
                            while (have_posts()) : the_post();
                                ?>
                                <div class="content-box">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="vk-img-frame">
                                            <a class="vk-img" href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail(); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <h2 class="vk-text-uppercase wicon-txt-title">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h2>
                                    <div class="entry-header">
                                        <div class="entry-meta">
                                            <?php wicon_posted_on(); ?>
                                        </div><!-- .entry-meta -->
                                    </div>
                                    <div class="content">
                                        <?php the_excerpt(); ?>
                                        <div class="vk-buttons">
                                            <a href="<?php the_permalink(); ?>"
                                               class="vk-btn vk-btn-transparent vk-btn-readmore text-uppercase">
                                                <?php echo esc_html__('READ MORE', 'wicon'); ?>
                                                <i class="fa fa-long-arrow-right vk-text-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="vk-divider"></div>
                                </div>
                            <?php
                            endwhile;
                            ?>
                            <!-- PAGE NUMBER -->
                            <nav class="box-pagination vk-text-right">
                                <ul class="vk-pagination">
                                    <?php echo wicon_get_pagination_links(); ?>
                                </ul>
                            </nav>
                            <?php
                        else :
                            echo esc_html__('No results found !', 'wicon');
                        endif;
                        ?>
                    </div>
                </div>
                <?php if (is_active_sidebar('sidebar-1')) : ?>
                <div class="col-md-3">
                    <?php get_sidebar(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <!------ END BLOG WRAPPER ------>
    </div>
</div>