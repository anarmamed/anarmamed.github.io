<?php
if (!is_404()) :
    if (is_object($post) && get_post_meta($post->ID, 'custom-header', true) == "Header 2") :
        echo "<div class='col-md-12'>";
    endif;
endif;
$fclass = array();

if (!is_active_sidebar('sidebar-footer1') && !is_active_sidebar('sidebar-footer2') && !is_active_sidebar('sidebar-footer3') && !is_active_sidebar('sidebar-footer4')) :
    $fclass[] = 'hidden-footer-top';
endif;
if (is_object($post) && get_post_meta($post->ID, 'custom-header', true) === "Header 2") :
    $fclass[] = 'row';
    endif;

if (is_object($post) && empty(get_post_meta($post->ID, 'custom-header', true))) :
    $fclass[] = "vikifooter-fix";
endif;
?>
    <footer class="vk-footer <?php echo esc_attr(implode(' ', $fclass)); ?>">
        <?php if (is_active_sidebar('sidebar-footer1') || is_active_sidebar('sidebar-footer2') || is_active_sidebar('sidebar-footer3') || is_active_sidebar('sidebar-footer4')) : ?>
            <div class="container">
                <div class="row">
                    <?php if (is_active_sidebar('sidebar-footer1')) : ?>
                        <div class="col-md-3">
                            <?php dynamic_sidebar('sidebar-footer1'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('sidebar-footer2')) : ?>
                        <div class="col-md-3">
                            <?php dynamic_sidebar('sidebar-footer2'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('sidebar-footer3')) : ?>
                        <div class="col-md-3">
                            <?php dynamic_sidebar('sidebar-footer3'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('sidebar-footer4')) : ?>
                        <div class="col-md-3">
                            <?php dynamic_sidebar('sidebar-footer4'); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <!--./row-->

            </div>
        <?php endif; ?>
        <?php if (is_active_sidebar('sidebar-footer5')) : ?>
            <div class="copyright">
                <?php dynamic_sidebar('sidebar-footer5'); ?>

            </div>
        <?php else : ?>
            <div class="copyright">
                <a href="<?php echo esc_url(('https://wordpress.org/')); ?>"><?php
                    /* translators: %s: CMS name, i.e. WordPress. */
                    printf(esc_html__('Proudly powered by %s', 'wicon'), 'WordPress');
                    ?></a>
                <span class="sep"> | </span>
                <?php
                /* translators: 1: Theme name, 2: Theme author. */
                printf(esc_html__('Theme: %1$s by %2$s.', 'wicon'), 'wicon', '<a href="' . esc_url('https://themeforest.net/user/ava-themes') . '" rel="nofollow">Ava Themes</a>');
                ?>
            </div>
            <?php
        endif;
        ?>

    </footer>
<?php
if (is_object($post) && get_post_meta($post->ID, 'custom-header', true) === "Header 2") :
    echo "</div>";
endif;
?>