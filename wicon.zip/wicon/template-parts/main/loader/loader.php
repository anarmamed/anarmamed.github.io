<!-- loadpage -->
<div class="loadpage">
    <?php
    if(get_theme_mod('garenal_preloading') === "loading1") :
        ?>
        <div class="spinner1"></div>
        <?php
    endif;
    ?>
    <?php
    if(get_theme_mod('garenal_preloading') === "loading2") :
        ?>
        <div class="spinner2">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
        <?php
    endif;
    ?>
    <?php
    if(get_theme_mod('garenal_preloading') === "loading3") :
        ?>
        <div class="spinner3">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
        </div>
        <?php
    endif;
    ?>

    <?php
    if(get_theme_mod('garenal_preloading') === "loading4") :
        ?>
        <div class="spinner4">
            <div class="cube1"></div>
            <div class="cube2"></div>
        </div>
        <?php
    endif;
    ?>

    <?php
    if(get_theme_mod('garenal_preloading') === "loading5") :
        ?>
        <div class="spinner5"></div>
        <?php
    endif;
    ?>

    <?php
    if(get_theme_mod('garenal_preloading') === "loading6") :
        ?>
        <div class="spinner6">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
        <?php
    endif;
    ?>

    <?php
    if(get_theme_mod('garenal_preloading') === "loading7") :
        ?>
        <div class="spinner7">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
        <?php
    endif;
    ?>

    <?php
    if(get_theme_mod('garenal_preloading') === "loading8") :
        ?>
        <div class="sk-circle8">
            <div class="sk-circle1 sk-child"></div>
            <div class="sk-circle2 sk-child"></div>
            <div class="sk-circle3 sk-child"></div>
            <div class="sk-circle4 sk-child"></div>
            <div class="sk-circle5 sk-child"></div>
            <div class="sk-circle6 sk-child"></div>
            <div class="sk-circle7 sk-child"></div>
            <div class="sk-circle8 sk-child"></div>
            <div class="sk-circle9 sk-child"></div>
            <div class="sk-circle10 sk-child"></div>
            <div class="sk-circle11 sk-child"></div>
            <div class="sk-circle12 sk-child"></div>
        </div>
        <?php
    endif;
    ?>

    <?php
    if(get_theme_mod('garenal_preloading') === "loading9") :
        ?>
        <div class="sk-cube-grid9">
            <div class="sk-cube sk-cube1"></div>
            <div class="sk-cube sk-cube2"></div>
            <div class="sk-cube sk-cube3"></div>
            <div class="sk-cube sk-cube4"></div>
            <div class="sk-cube sk-cube5"></div>
            <div class="sk-cube sk-cube6"></div>
            <div class="sk-cube sk-cube7"></div>
            <div class="sk-cube sk-cube8"></div>
            <div class="sk-cube sk-cube9"></div>
        </div>
        <?php
    endif;
    ?>

    <?php
    if(get_theme_mod('garenal_preloading') === "loading10") :
        ?>
        <div class="sk-fading-circle10">
            <div class="sk-circle1 sk-circle"></div>
            <div class="sk-circle2 sk-circle"></div>
            <div class="sk-circle3 sk-circle"></div>
            <div class="sk-circle4 sk-circle"></div>
            <div class="sk-circle5 sk-circle"></div>
            <div class="sk-circle6 sk-circle"></div>
            <div class="sk-circle7 sk-circle"></div>
            <div class="sk-circle8 sk-circle"></div>
            <div class="sk-circle9 sk-circle"></div>
            <div class="sk-circle10 sk-circle"></div>
            <div class="sk-circle11 sk-circle"></div>
            <div class="sk-circle12 sk-circle"></div>
        </div>
        <?php
    endif;
    ?>


    <?php
    if(get_theme_mod('garenal_preloading') === "loading11") :
        ?>
        <div class="sk-folding-cube11">
            <div class="sk-cube1 sk-cube"></div>
            <div class="sk-cube2 sk-cube"></div>
            <div class="sk-cube4 sk-cube"></div>
            <div class="sk-cube3 sk-cube"></div>
        </div>
        <?php
    endif;
    ?>
</div>