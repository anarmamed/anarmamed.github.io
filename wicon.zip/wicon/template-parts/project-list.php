<?php
/*
    Template Name: ProjectList
*/

get_header();
?>
    <section class="vk-content">
        <div class="vk-banner vk-background-image-3">
            <div class="vk-background-overlay vk-background-black-1 _80"></div>
            <div class="container wrapper">
                <div class="page-heading">
                    <?php the_title('<h1 class="page-title">', '</h1>'); ?>
                </div>
            </div>
        </div>
        <div class="vk-breadcrumb">
            <nav class="container">
                <div class="">
                    <ul>
                        <li>
                            <a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html__('home', 'wicon'); ?></a>
                        </li>

                        <li class="active"><?php echo the_title(); ?></li>
                    </ul>
                </div>
            </nav>
        </div>
        <!--./vk-breadcrumb-->
        <div class="vk-page vk-page-project vk-page-project-list vk-space x-large">
            <div class="container">
                <nav class="box-filter text-center clearfix">

                    <ul class="vk-filter vk-filter-button hidden-xs hidden-sm">

                        <li class="data-filter" data-filter="*">all</li>
                        <?php
                        $term_tax = get_terms(array(
                            'taxonomy' => 'project_cats',
                            'hide_empty' => false,
                        ));
                        if (!is_wp_error($term_tax)) :
                            foreach ($term_tax as $item):
                                ?>

                                <li class="data-filter"
                                    data-filter=".data-<?php echo esc_attr($item->slug); ?>"><?php echo esc_attr($item->name); ?></li>
                            <?php endforeach;
                        endif; ?>
                    </ul>
                    <!--./vk-filter-->

                    <select class="vk-filter vk-filter-button form-control hidden-md hidden-lg">

                        <option class="data-filter" value="*">all</option>
                        <?php
                        if (!is_wp_error($term_tax)) :
                            foreach ($term_tax as $item2):
                                ?>
                                <option class="data-filter"
                                        value=".data-<?php echo esc_attr($item2->slug); ?>"><?php echo esc_attr($item2->name); ?></option>
                            <?php endforeach;
                        endif;
                        ?>
                    </select>
                    <!--./vk-filter-->
                </nav>
                <!--./box-filter-->

                <div class="vk-project-list clearfix vk-masonry-layout">
                    <?php
                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    $args = array(
                        'post_type' => 'pt_project',
                        'posts_per_page' => 6,
                        'order' => 'desc',
                        'paged' => $paged
                    );
                    $query = new WP_Query($args);
                    if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
                        ?>

                        <div class="vk-project vk-project-list-item item data-<?php
                        $get_term = get_the_terms($post->ID, 'project_cats');

                        foreach ($get_term as $get_term) {
                            echo esc_attr($get_term->slug);
                        }
                        ?>">

                            <div class="col-md-4 left-content">
                                <?php if (has_post_thumbnail()) { ?>
                                    <div class="vk-img-frame">
                                        <a href="<?php the_permalink(); ?>" class="vk-img">
                                            <?php the_post_thumbnail('wicon-blog-thumb'); ?>
                                        </a>
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="col-md-8 right-content">
                                <h4 class="vk-title text-uppercase">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h4>
                                <ul class="vk-list vk-list-inline vk-detail-post">
                                    <li><?php echo esc_html__('Client:', 'wicon'); ?> <span
                                                class="vk-text-color-yellow-1 vk-text"><?php
                                            $get_term2 = get_the_terms($post->ID, 'project_cats');
                                            foreach ($get_term2 as $get_term2) {
                                                echo esc_attr($get_term2->name);
                                            }
                                            ?></span></li>
                                    <li><?php echo esc_html__('Year completed:', 'wicon'); ?> <span
                                                class="vk-text-color-yellow-1 vk-text"><?php echo get_the_date('Y'); ?></span>
                                    </li>
                                    <li><?php echo esc_html__('Project leader:', 'wicon'); ?> <span
                                                class="vk-text-color-yellow-1 vk-text"><?php the_author(); ?></span>
                                    </li>
                                </ul>
                                <?php echo get_the_excerpt($post->ID); ?>
                                <div class="vk-buttons">
                                    <a href="<?php the_permalink(); ?>"
                                       class="vk-btn vk-btn-transparent text-uppercase vk-btn-readmore"><?php echo esc_html__('further information', 'wicon'); ?>
                                        <i class="fa fa-long-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php
                    endwhile;
                    endif;
                    wp_reset_postdata();
                    ?>
                </div>
                <!--./vk-project-list-->

                <nav class="box-pagination">
                    <?php
                    global $query_args;

                    $big = 999999999; // need an unlikely integer

                    echo paginate_links(array(
                        'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                        'format' => '?paged=%#%',
                        'current' => max(1, get_query_var('paged')),
                        'total' => $query->max_num_pages,
                        'prev_next' => True,
                        'prev_text' => esc_html__('Prev', 'wicon'),
                        'next_text' => esc_html__('Next', 'wicon')
                    ));
                    ?>
                    <!--./vk-pagination-->
                </nav>
                <!--./box-pagination-->
            </div>
            <!--./container-->
        </div>
        <!--./vk-page-->
    </section>
<?php

get_footer();