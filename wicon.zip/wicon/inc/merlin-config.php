<?php
if (!class_exists('Merlin')) {
    return;
}

/**
 * Set directory locations, text strings, and other settings for Merlin WP.
 */
$wizard = new Merlin(
// Configure Merlin with custom settings.
    $config = array(
        'directory' => '', // Location where the 'merlin' directory is placed.
        'merlin_url' => 'merlin', // Customize the page URL where Merlin WP loads.
        'child_action_btn_url' => 'https://codex.wordpress.org/Child_Themes',  // The URL for the 'child-action-link'.
        'help_mode' => false, // Set to true to turn on the little wizard helper.
        'dev_mode' => true, // Set to true if you're testing or developing.
        'branding' => true, // Set to false to remove Merlin WP's branding.
    ),
    // Text strings.
    $strings = array(
        'admin-menu' => esc_html__('Theme Setup', 'wicon'),
        'title%s%s%s%s' => esc_html__('%s%s Themes &lsaquo; Theme Setup: %s%s', 'wicon'),

        'return-to-dashboard' => esc_html__('Return to the dashboard', 'wicon'),

        'btn-skip' => esc_html__('Skip', 'wicon'),
        'btn-next' => esc_html__('Next', 'wicon'),
        'btn-start' => esc_html__('Start', 'wicon'),
        'btn-no' => esc_html__('Cancel', 'wicon'),
        'btn-plugins-install' => esc_html__('Install', 'wicon'),
        'btn-child-install' => esc_html__('Install', 'wicon'),
        'btn-content-install' => esc_html__('Install', 'wicon'),
        'btn-import' => esc_html__('Import', 'wicon'),

        'welcome-header%s' => esc_html__('Welcome to %s', 'wicon'),
        'welcome-header-success%s' => esc_html__('Hi. Welcome back', 'wicon'),
        'welcome%s' => esc_html__('This wizard will set up your theme, install plugins, and import content. It is optional & should take only a few minutes.', 'wicon'),
        'welcome-success%s' => esc_html__('You may have already run this theme setup wizard. If you would like to proceed anyway, click on the "Start" button below.', 'wicon'),

        'child-header' => esc_html__('Install Child Theme', 'wicon'),
        'child-header-success' => esc_html__('You\'re good to go!', 'wicon'),
        'child' => esc_html__('Let\'s build & activate a child theme so you may easily make theme changes.', 'wicon'),
        'child-success%s' => esc_html__('Your child theme has already been installed and is now activated, if it wasn\'t already.', 'wicon'),
        'child-action-link' => esc_html__('Learn about child themes', 'wicon'),
        'child-json-success%s' => esc_html__('Awesome. Your child theme has already been installed and is now activated.', 'wicon'),
        'child-json-already%s' => esc_html__('Awesome. Your child theme has been created and is now activated.', 'wicon'),

        'plugins-header' => esc_html__('Install %d plugins', 'wicon'),
        'plugins-header-success' => esc_html__('You\'re up to speed!', 'wicon'),
        'plugins' => esc_html__('Let\'s install some essential WordPress plugins to get your site up to speed.', 'wicon'),
        'plugins-success%s' => esc_html__('The required WordPress plugins are all installed and up to date. Press "Next" to continue the setup wizard.', 'wicon'),
        'plugins-action-link' => esc_html__('Advanced', 'wicon'),

        'import-header-1' => esc_html__('Choose your own theme', 'wicon'),
        'import-1' => esc_html__('See %d+ home layouts', 'wicon'),
        'import-header-2' => esc_html__('Choose Your Theme', 'wicon'),
        'import-2' => esc_html__('There are many unique and sophisticated theme are available on Wicon that you can choose the one is suitable for your use', 'wicon'),
        'import-header-3' => esc_html__('Import data', 'wicon'),
        'import-3' => esc_html__('You will get the demo data of the theme which you chose and you can customize it if you want', 'wicon'),
        'import-header-4' => esc_html__('Importing...', 'wicon'),
        'import-4' => esc_html__('Please be patient. It will be ended soon.
			Do not quit or shut down your browser', 'wicon'),
        'process-4' => esc_html__('Importing Wicon data', 'wicon'),

        'import-header' => esc_html__('Import Content', 'wicon'),
        'import' => esc_html__('Let\'s import content to your website, to help you get familiar with the theme.', 'wicon'),
        'import-action-link' => esc_html__('Advanced', 'wicon'),

        'ready-header' => esc_html__('Import Successfully!!!', 'wicon'),
        'ready%s' => esc_html__('Your site has been set up successfully. Enjoy your new site by %s', 'wicon'),
        'ready-action-link' => esc_html__('Extras', 'wicon'),
        'ready-big-button' => esc_html__('View your site', 'wicon'),

        'ready-link-1' => wp_kses(sprintf('<a href="%1$s" target="_blank">%2$s</a>', 'https://wordpress.org/support/', esc_html__('Explore WordPress', 'wicon')), array('a' => array('href' => array(), 'target' => array()))),
        'ready-link-3' => wp_kses(sprintf('<a href="' . admin_url('customize.php') . '" target="_blank">%s</a>', esc_html__('Start Customizing', 'wicon')), array('a' => array('href' => array(), 'target' => array()))),
    ),
    $plugins = array(
        array(
            'name' => esc_html__('Contact Form 7', 'wicon'),
            'slug' => 'contact-form-7',
            'required' => false,
            'version' => '',
        ),

        array(
            'name' => esc_html__('Menu Icons', 'wicon'),
            'slug' => 'menu-icons',
            'required' => false,

        ),

        array(
            'name' => esc_html__('WooCommerce', 'wicon'),
            'slug' => 'woocommerce',
            'required' => false,
            'version' => '',
            'force_activation' => false,
            'force_deactivation' => false,
        ),

        array(
            'name' => esc_html__('Smart Slider 3', 'wicon'),
            'slug' => 'smart-slider-3',
            'required' => false,
            'version' => '',
        ),

        array(
            'name' => 'WPBakery Page Builder',
            'slug' => 'js_composer',
            'required' => false,
            'version' => '',
            'source' => get_parent_theme_file_path() . '/inc/import-files/plugins/js_composer.zip',
        ),

        array(
            'name' => esc_html__('Wp Grid Plus', 'wicon'),
            'slug' => 'grid-plus',
            'required' => false,

        ),

    )
);

function wicon_local_import_files()
{
    return array(
        array(
            'import_file_name' => 'default',
            'local_import_file_data' => get_parent_theme_file_path('inc/import-files/demo/demo-content.xml'),
            'local_import_widget_file' => get_parent_theme_file_path('inc/import-files/demo/widgets.wie'),
            'local_import_customizer_file' => get_parent_theme_file_path('inc/import-files/demo/customize.dat'),

            'local_import_smart_slider_file' => get_parent_theme_file_path('inc/import-files/smartslider/default.ss3'),
            'local_import_smart_slider_file2' => get_parent_theme_file_path('inc/import-files/smartslider/shop.ss3'),
            'local_import_smart_slider_file3' => get_parent_theme_file_path('inc/import-files/smartslider/leftmenu.ss3'),
            'local_import_smart_slider_file4' => get_parent_theme_file_path('inc/import-files/smartslider/homeslider.ss3'),
            'local_import_smart_slider_file5' => get_parent_theme_file_path('inc/import-files/smartslider/onepage.ss3'),
            'local_import_smart_slider_file6' => get_parent_theme_file_path('inc/import-files/smartslider/builder.ss3'),
            'local_import_smart_slider_file7' => get_parent_theme_file_path('inc/import-files/smartslider/luxury.ss3'),

            'import_preview_image_url' => 'http://wp.vikitheme.com/wicon/wp-content/uploads/2019/06/import-screenshot.jpg',
            'import_notice' => esc_html__('After you import this demo, you will have to setup the slider separately.', 'wicon'),
            'preview_url' => 'http://wp.vikitheme.com/wicon',
            'title_home_page' => 'Home Default',
            'menu_settings' => array(
                'primary' => 'Home default'
            ),
        ),

    );
}

add_filter('merlin_import_files', 'wicon_local_import_files');