<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wicon
 */

?>
<?php
$wicon_page_layout = get_theme_mod('page_layouts', 'no-sidebar');
$meta_page_layout = get_post_meta($post->ID, 'page-meta-layout', true);

$layout_container_class = '';
$wicon_sidebar_class = '';
$col_class = array();

if ($meta_page_layout !== '' && $meta_page_layout !== 'default') :
    if ($meta_page_layout === 'full') :
        $layout_container_class = 'container-fuild';
        $col_class[] = 'col-md-12 ';
    else :
        $layout_container_class = 'container';
        if ($meta_page_layout !== 'no-sidebar' && is_active_sidebar('sidebar-1')) :
            $col_class[] = 'col-md-9 ';
        else :
            $col_class[] = 'col-md-12 ';
        endif;

    endif;

    if ($meta_page_layout === 'left') :
        $col_class[] = 'col-md-push-3 ';
        $wicon_sidebar_class = 'col-md-pull-9';
    endif;

else :
    if ($wicon_page_layout === 'full') :
        $layout_container_class = 'container-fuild';
        $col_class[] = 'col-md-12 ';
    else :
        $layout_container_class = 'container';
        if ($wicon_page_layout !== 'no-sidebar' && is_active_sidebar('sidebar-1')) :
            $col_class[] = 'col-md-9 ';
        else :
            $col_class[] = 'col-md-12 ';
        endif;

    endif;
    if ($wicon_page_layout === 'left') :
        $col_class[] = 'col-md-push-3 ';
        $wicon_sidebar_class = 'col-md-pull-9';
    endif;
endif;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="<?php echo esc_attr($layout_container_class); ?>">
        <div class="row">
            <div class="<?php echo esc_attr(implode(' ', $col_class)); ?>">
                <div class="entry-content">
                    <?php
                    the_content();
                    // If comments are open or we have at least one comment, load up the comment template.

                    wp_link_pages(array(
                            'link_before' => '<span>',
                            'link_after' => '</span>',
                            'pagelink' => '%',
                            'before' => '<div class="blog-pagination">',
                            'after' => '</div>',
                            'nextpagelink' => esc_html__('&rarr;', 'wicon'),
                            'previouspagelink' => esc_html__('&larr;', 'wicon'),
                        )
                    );
                    ?>
                </div><!-- .entry-content -->
                <?php
                if (comments_open() || get_comments_number()) : ?>
                    <div class="comment-plugin-active">
                        <?php
                        comments_template();
                        ?>
                    </div>
                <?php endif; ?>

            </div>
            <?php
            if ($meta_page_layout === '') :
                if ($wicon_page_layout === 'left' || $wicon_page_layout === 'right' && is_active_sidebar('sidebar-1')) :
                    ?>
                    <div class="col-md-3 <?php echo esc_attr($wicon_sidebar_class); ?>">
                        <?php get_sidebar(); ?>
                    </div>
                    <?php
                endif;

            else :
                if ($meta_page_layout === 'right-sidebar' || $meta_page_layout === 'left-sidebar' || ($meta_page_layout === 'default' && $wicon_page_layout === 'left') || ($meta_page_layout === 'default' && $wicon_page_layout === 'right') && is_active_sidebar('sidebar-1')) :
                    ?>
                    <div class="col-md-3 <?php echo esc_attr($wicon_sidebar_class); ?>">
                        <?php get_sidebar(); ?>
                    </div>
                    <?php
                endif;
            endif;
            ?>
        </div>
    </div>
</article><!-- #post-<?php the_ID(); ?> -->
