<div class="animsition main-wrapper">
    <header class="vk-header vk-header-one-page vk-header-transparent vk-header-home vk-header5">
        <nav class="vk-navbar  navbar">
            <div class="container">
                <div class="vk-navbar-header navbar-header">
                    <button type="button" class="navbar-toggle vk-navbar-toggle collapsed" data-toggle="collapse"
                            data-target="#myNavbar">
                        <i class="toggle-icon"></i>
                    </button>
                    <?php 
                    if(get_theme_mod('display_cart', true)){
                    if (class_exists('WooCommerce')) : ?>
                        <div class="shopping-cart hidden-md hidden-lg">
                            <i class="fa fa-shopping-basket" data-toggle="collapse"
                               data-target="#shopping-cart-list"></i>
                            <?php global $woocommerce; ?>
                            <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                        </div>
                    <?php endif; 
                    }
                    ?>
                    <a class="vk-navbar-brand navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                        <?php if (!empty(get_theme_mod('logo_header5'))) : ?>
                            <img src="<?php echo esc_url(get_theme_mod('logo_header5')); ?>" alt="<?php esc_attr_e('logo', 'wicon') ?>" class="logo">
                        <?php
                        else:
                            ?>
                            <svg version="1.1" id="wicon-logo-svg" xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="290.037px"
                                 height="290.25px" viewBox="0 0 290.037 290.25"
                                 enable-background="new 0 0 290.037 290.25" xml:space="preserve">
                    <polygon fill="#FFC000"
                             points="170,60.25 50,60.25 0,60.25 0,110.25 0,290.25 50,290.25 50,110.25 170,110.25 "></polygon>
                                <polygon fill="#FFC000" points="60.038,120.25 60.038,240.25 60.038,290.25 110.038,290.25 290.037,290.25 290.037,240.25
110.038,240.25 110.038,120.25 "></polygon>
                                <polygon fill="#FFC000"
                                         points="120.019,230 240.019,230 290.019,230 290.019,180 290.019,0 240.019,0 240.019,180 120.019,180 "></polygon>
                                <polygon fill="#FFC000"
                                         points="229.98,170 229.98,50 229.98,0 179.98,0 -0.019,0 -0.019,50 179.98,50 179.98,170 "></polygon>
                </svg>
                            <span class="logo-text text-uppercase"><?php echo esc_html__('WICON', 'wicon') ?></span>
                        <?php
                        endif;
                        ?>
                    </a>
                    <!--./vk-navbar-brand-->
                    <?php if(get_theme_mod('display_cart', true)){
                        if (class_exists('WooCommerce')) : ?>
                        <div class="shopping-cart-list collapse" id="shopping-cart-list">
                            <div class="vk-table woo-mini-cart">
                                <ul class="vk-table-row">
                                    <li class="vk-table-data"><?php echo esc_html__('product', 'wicon'); ?></li>
                                </ul>
                                <?php woocommerce_mini_cart(); ?>
                            </div>
                        </div>
                    <?php endif; 
                    } ?>

                </div>
                <!--./vk-navbar-header-->

                <div class="collapse navbar-collapse vk-navbar-collapse" id="menu">
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'primary',
                            'container' => 'ul',
                            'menu_class' => 'vk-navbar-nav navbar-right',
                            'echo' => true,
                        )
                    );
                    ?>
                    <!--./vk-navbar-nav-->
                    <?php if(get_theme_mod('display_search', true)){ ?>
                    <div class="box-search-header collapse" id="box-search-header">
                        <div class="vk-input-group">
                            <?php get_search_form(); ?>
                            <button class="vk-btn btn-search"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
            <!--./container-->
        </nav>
        <!--./vk-navbar-->
    </header>
    <div class="vk-navbar-right-fixed">
        <ul class="search-shopcart-button vk-list ">
            <?php 
            if(get_theme_mod('display_cart', true)){
            if (class_exists('WooCommerce')) : ?>
                <li>
                    <div class="shopping-cart">
                        <i class="fa fa-shopping-basket" data-toggle="collapse" data-target="#shopping-cart-list"></i>
                        <?php global $woocommerce; ?>
                        <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                    </div>
                </li>
            <?php endif; 
            }
            ?>
            <?php if(get_theme_mod('display_search', true)){ ?>
            <li class="item-search">
                <span class="btn-search" data-toggle="collapse" data-target="#box-search-header"><i class="fa fa-search"></i></span>
            </li>
            <?php } ?>

        </ul>
        <ul id="navScroll2Id" class="vk-list vk-nav-scroll-to-id">
            <?php
            $fullpage = get_theme_mod('fullpage_setting');
            if ($fullpage):
                foreach ($fullpage as $item) :
                    ?>
                    <li class="current"><a href="#<?php echo esc_attr($item['link_text']); ?>"></a></li>
                <?php
                endforeach;
            endif;
            ?>
        </ul>
        <?php
        $config_social = get_theme_mod('config_social_header', '');
        $link_facebook = $link_twiter = $link_google = "";
        if (!empty(get_theme_mod('facebook_header'))) :
            $link_facebook = get_theme_mod('facebook_header');
        endif;
        if (!empty(get_theme_mod('twitter_header'))) :
            $link_twiter = get_theme_mod('twitter_header');
        endif;
        if (!empty(get_theme_mod('google_header'))) :
            $link_google = get_theme_mod('google_header');
        endif;

        if ($config_social !== '') :
            echo '<ul class="vk-list vk-social-link">';
            foreach ($config_social as $item) :
                if ($item === "Facebook" && $link_facebook !== '') :
                    echo '<li><a href="' . esc_url($link_facebook) . '"><i class="fa fa-facebook"></i></a></li>';
                endif;

                if ($item === "Twitter" && $link_twiter !== '') :
                    echo '<li><a href="' . esc_url($link_twiter) . '"><i class="fa fa-twitter"></i></a></li>';
                endif;

                if ($item === "Google" && $link_google !== '') :
                    echo '<li><a href="' . esc_url($link_google) . '"><i class="fa fa-google-plus"></i></a></li>';
                endif;
            endforeach;
            echo '</ul>';
        endif;
        ?>
    </div>
