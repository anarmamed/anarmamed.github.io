<div class="animsition main-wrapper">
    <header class="vk-header vk-header-two-nav vk-header4">
        <nav class="vk-navbar navbar">
            <div class="container">
                    <?php 
                    if(get_theme_mod('display_cart', true)){
                    if ( class_exists( 'WooCommerce' ) ) : ?>
                    <div class="shopping-cart-list collapse" id="shopping-cart-list">
                        <div class="vk-table woo-mini-cart">
                            <ul class="vk-table-row">
                                <li class="vk-table-data"><?php echo esc_html__('product', 'wicon'); ?></li>
                            </ul>
                            <?php woocommerce_mini_cart(); ?>
                        </div>
                    </div>
                    <?php endif; 
                    }
                    ?>                    
                    <div class="vk-navbar-header navbar-header">
                        <div class="vk-divider left hidden-xs hidden-sm"></div>
                        <div class="vk-divider right hidden-xs hidden-sm"></div>
                        <button type="button" class="navbar-toggle vk-navbar-toggle collapsed" data-toggle="collapse">
                            <i class="toggle-icon"></i>
                        </button>
                        <!--./vk-navbar-toggle-->
                        <?php 
                        if(get_theme_mod('display_cart', true)){
                        if ( class_exists( 'WooCommerce' ) ) : ?>
                            <div class="shopping-cart hidden-md hidden-lg">
                                <i class="fa fa-shopping-basket" data-toggle="collapse"
                                   data-target="#shopping-cart-list"></i>
                                <?php global $woocommerce; ?>
                                <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                            </div>
                            <!--./shopping-cart-->
                        <?php endif; 
                        }
                        ?>
                        <a class="vk-navbar-brand navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                            <?php if (!empty(get_theme_mod('logo_header4'))) : ?>
                                <img src="<?php echo esc_url(get_theme_mod('logo_header4')); ?>" alt="<?php esc_attr_e('logo', 'wicon') ?>" class="logo">
                            <?php else: ?>
                                <svg version="1.1" id="wicon-logo-svg" xmlns="http://www.w3.org/2000/svg"
                                     xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="290.037px"
                                     height="290.25px" viewBox="0 0 290.037 290.25"
                                     enable-background="new 0 0 290.037 290.25" xml:space="preserve">
                    <polygon fill="#FFC000"
                             points="170,60.25 50,60.25 0,60.25 0,110.25 0,290.25 50,290.25 50,110.25 170,110.25 "></polygon>
                                    <polygon fill="#FFC000" points="60.038,120.25 60.038,240.25 60.038,290.25 110.038,290.25 290.037,290.25 290.037,240.25
110.038,240.25 110.038,120.25 "></polygon>
                                    <polygon fill="#FFC000"
                                             points="120.019,230 240.019,230 290.019,230 290.019,180 290.019,0 240.019,0 240.019,180 120.019,180 "></polygon>
                                    <polygon fill="#FFC000"
                                             points="229.98,170 229.98,50 229.98,0 179.98,0 -0.019,0 -0.019,50 179.98,50 179.98,170 "></polygon>
                </svg>
                                <span class="logo-text text-uppercase"><?php echo esc_html__('WICON', 'wicon') ?></span>
                            <?php
                            endif;
                            ?>
                        </a>
                    </div>
                    <!--./vk-navbar-header-->

                    <div class="collapse navbar-collapse vk-navbar-collapse" id="menu">
                        <ul class="vk-navbar-nav vk-navbar-left">
                            <?php
                            wp_nav_menu(
                                array(
                                    'theme_location' => 'primary',
                                    'container' => 'ul',
                                    'menu_class' => 'vk-navbar-nav vk-navbar-left',
                                    'menu' => 'menu header 4-1'
                                )
                            );
                            ?>

                        </ul>
                        <ul class="vk-navbar-nav vk-navbar-right">
                            <?php
                            wp_nav_menu(
                                array(
                                    'theme_location' => 'primary',
                                    'container' => 'ul',
                                    'menu_class' => 'vk-navbar-nav vk-navbar-right',
                                    'menu' => 'menu header 4-2'
                                )
                            );
                            ?>
                        </ul>
                        <?php if(get_theme_mod('display_search', true)){ ?>
                        <div class="box-search-header collapse" id="box-search-header" aria-expanded="false"
                             role="search">
                            <div class="vk-input-group">
                                <?php
                                get_search_form();
                                ?>
                                <button class="vk-btn btn-search"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
            </div>
            <!--./container-->
        </nav>
        <!--./vk-navbar-->

        <div class="vk-header-top hidden-xs hidden-sm">
            <div class="container">
                <div class="row">
                    <div class="content">
                        <?php 
                        if(get_theme_mod('display_cart', true)){
                        if ( class_exists( 'WooCommerce' ) ) : ?>
                            <div class="shopping-cart">
                                <i class="fa fa-shopping-basket" data-toggle="collapse"
                                   data-target="#shopping-cart-list"></i>
                                <?php global $woocommerce; ?>
                                <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                            </div>
                        <?php endif; 
                        }
                        ?>
                        <ul class="quick-address">
                            <?php if (!empty(get_theme_mod('time_header'))) :
                                echo '<li>'.esc_html(get_theme_mod('time_header')).'</li>';
                            endif;
                            ?>
                            <?php if(get_theme_mod('display_search', true)){ ?>
                            <li class="item-search">
                                <span class="btn-search hidden-xs hidden-sm" data-toggle="collapse" data-target="#box-search-header"><i class="fa fa-search"></i></span>
                            </li>
                            <?php } ?>
                        </ul>
                        <ul class="quick-address vk-navbar-left">
                            <?php if (!empty(get_theme_mod('phone_header'))) : ?>
                                <li><?php echo esc_html(get_theme_mod('phone_header')); ?></li>
                                <?php
                            endif;

                            if (!empty(get_theme_mod('email_header'))) : ?>
                                <li><?php echo esc_html(get_theme_mod('email_header')); ?></li>
                            <?php
                            endif;
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>