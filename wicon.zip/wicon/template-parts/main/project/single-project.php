<div class="vk-page vk-page-project vk-single-project">
    <div class="container">
      <?php 
      $filesimg = get_post_meta(get_the_ID(), 'wicon_single_prefix_slider_single_project', true);
      $project_gallery_style = get_post_meta(get_the_ID(), 'wicon_project_gallery_style', true);
      ?>
      <?php if ($project_gallery_style =='lightbox') : ?>
        <?php
          if (!empty($filesimg)) :
            echo '<div class="project-gallery-lightbox">';
            $attr[] = '"arrows": false, "dots":true , "slidesToShow": "6"';
            $attr[] = '"responsive": [{"breakpoint": 992,"settings": {"arrows": false,"slidesToShow": 4,"slidesToScroll": 4}},{"breakpoint": 600,"settings": {"arrows": false,"slidesToShow": 3,"slidesToScroll": 3}}]';
            
            $data_slick = 'data-slick=\'{' . esc_attr(implode(', ', $attr)) . '}\'';
            
            if(is_array($filesimg)){
                echo '<div class="image-set uni-wicon-slider" '.$data_slick.'>';
                          foreach ($filesimg as $img_id => $img_url):
                              $image_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);                              
                              ?>
                              <a class="example-image-link" href="<?php echo $img_url; ?>" data-lightbox="example-set" <?php if($image_alt !=''){ echo 'data-title="'.$image_alt.'"'; } ?> ><?php echo wp_get_attachment_image($img_id, 'thumbnail'); ?></a>
                              <?php 
                          endforeach;
                   echo '</div>';          
              
              }else{
                echo '<div class="image-set uni-wicon-slider" '.$data_slick.'>';
                $files3 = explode(',', $filesimg);
                foreach ($files3 as $img_id):
                    $src = wp_get_attachment_image_src($img_id, 'thumbnail');
                    $src_full = wp_get_attachment_image_src($img_id, 'full');
                    $image_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
                    if($image_alt !=''){
                      $ialt = 'alt="'.$image_alt.'"';
                      $titleimg = 'data-title="'.$image_alt.'"';
                    }else{
                      $ialt ='';
                      $titleimg = '';
                    }
                    ?>
                    <a class="example-image-link" href="<?php echo $src_full[0]; ?>" data-lightbox="example-set" <?php echo $titleimg; ?>>
                    <?php echo '<img src="' . $src[0] . '" '.$ialt.'>'; ?>
                    </a>
                    <?php

                endforeach;
                echo '</div>';    
              }
              echo '</div>';
          endif;
          ?>

      <?php else: ?>
        <?php      
        if (!empty($filesimg)) :
          if(is_array($filesimg)){
        ?>
                    <div class="vk-slider-project">
                        <div class="slider-for">
                            <?php
                            foreach ($filesimg as $img_id => $img_url):
                                echo wp_get_attachment_image($img_id, 'full');
                            endforeach;
                             ?>
                        </div>
                        <div class="slider-nav row">
                            <?php
                            foreach ($filesimg as $img_id => $img_url):
                                ?>
                                <div class="col-md-2">
                                    <div class="vk-img-frame">
                                        <?php echo wp_get_attachment_image($img_id, 'medium'); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php
          }else{
                    $files2 = explode(',', $filesimg);
                    ?>
                    <div class="vk-slider-project">
                        <div class="slider-for">
                            <?php
                            foreach ($files2 as $img_id):
                                $src = wp_get_attachment_image_src($img_id, 'full');
                                echo '<img src="' . $src[0] . '">';
                            endforeach; ?>
                        </div>
                        <div class="slider-nav row">
                            <?php
                            foreach ($files2 as $img_id2 ):
                                ?>
                                <div class="col-md-2">
                                    <div class="vk-img-frame">
                                        <?php
                                        $src_thumb = wp_get_attachment_image_src($img_id2, 'medium');
                                        echo '<img src="' . $src_thumb[0] . '">';
                                        ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php
            }

          else:
            the_post_thumbnail();
          endif;
          ?>

      <?php endif; ?>
      <!-- end gallery -->
      
      <?php if(get_theme_mod('project_detail_layout', 'default') == 'contactfrm'):   ?>
            <div class="vk-content-single-project">
                <div class="row">
                    <div class="col-md-6">
                        <div class="info">
                            <h4 class="vk-title text-uppercase"><?php echo esc_html__('INFORMATION', 'wicon'); ?></h4>
                            <table>
                                <?php
                                if (!empty(get_post_meta(get_the_ID(), 'wicon_single_prefix_client_project_text', true))):
                                    ?>
                                    <tr>
                                        <th><?php echo esc_html__('Client:', 'wicon'); ?></th>
                                        <td><?php echo get_post_meta(get_the_ID(), 'wicon_single_prefix_client_project_text', true); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <?php
                                if (!empty(get_post_meta(get_the_ID(), 'wicon_single_prefix_location_project_text', true))):
                                    ?>
                                    <tr>
                                        <th><?php echo esc_html__('Location:', 'wicon'); ?></th>
                                        <td><?php echo get_post_meta(get_the_ID(), 'wicon_single_prefix_location_project_text', true); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <?php
                                if (!empty(get_post_meta(get_the_ID(), 'wicon_single_prefix_year_project_text', true))):
                                    ?>
                                    <tr>
                                        <th><?php echo esc_html__('Year completed:', 'wicon'); ?></th>
                                        <td><?php echo get_post_meta(get_the_ID(), 'wicon_single_prefix_year_project_text', true); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <?php
                                if (!empty(get_post_meta(get_the_ID(), 'wicon_single_prefix_leader_project_text', true))):
                                    ?>
                                    <tr>
                                        <th><?php echo esc_html__('Project leader:', 'wicon'); ?></th>
                                        <td><?php echo get_post_meta(get_the_ID(), 'wicon_single_prefix_leader_project_text', true); ?></td>
                                    </tr>
                                <?php endif; ?>
                                <?php 
                                $get_term2 = get_the_terms($post->ID, 'project_cats'); 
                                if($get_term2):
                                ?>
                                  <tr>
                                      <th><?php echo esc_html__('Category:', 'wicon'); ?></th>
                                      <td><?php                                          
                                          foreach ($get_term2 as $get_term2) :
                                              echo esc_attr($get_term2->name);
                                          endforeach;
                                          ?>                                          
                                      </td>
                                  </tr>
                                <?php endif; ?>
                            </table>
                        </div>                    
                    </div>                    
                    <div class="col-md-6">
                        <?php
                        $frm_contact = get_theme_mod('project_contact_form', '');
                        if(isset($frm_contact) && $frm_contact !=''){
                        echo '<div class="info project-contact-frm">';
                        echo do_shortcode('[contact-form-7 title="Contact form" id='.$frm_contact.' ]');    
                        echo '</div>';
                        }
                        
                        ?>
                    </div>
                    <div class="col-md-12">
                        <div class="info description">
                            <h4 class="vk-title text-uppercase"><?php echo esc_html__('description', 'wicon'); ?></h4>
                            <p><?php the_content(); ?></p>
                        </div>                    
                    </div>
                    
                </div>            
            </div>

          <?php else: ?>
            <div class="vk-content-single-project">
                <div class="row">
                    <div class="col-md-6">
                        <div class="info">
                            <h4 class="vk-title text-uppercase"><?php echo esc_html__('INFORMATION', 'wicon'); ?></h4>
                            <table>
                                <?php
                                if (!empty(get_post_meta(get_the_ID(), 'wicon_single_prefix_client_project_text', true))):
                                    ?>
                                    <tr>
                                        <th><?php echo esc_html__('Client:', 'wicon'); ?></th>
                                        <td><?php echo get_post_meta(get_the_ID(), 'wicon_single_prefix_client_project_text', true); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <?php
                                if (!empty(get_post_meta(get_the_ID(), 'wicon_single_prefix_location_project_text', true))):
                                    ?>
                                    <tr>
                                        <th><?php echo esc_html__('Location:', 'wicon'); ?></th>
                                        <td><?php echo get_post_meta(get_the_ID(), 'wicon_single_prefix_location_project_text', true); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <?php
                                if (!empty(get_post_meta(get_the_ID(), 'wicon_single_prefix_year_project_text', true))):
                                    ?>
                                    <tr>
                                        <th><?php echo esc_html__('Year completed:', 'wicon'); ?></th>
                                        <td><?php echo get_post_meta(get_the_ID(), 'wicon_single_prefix_year_project_text', true); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <?php
                                if (!empty(get_post_meta(get_the_ID(), 'wicon_single_prefix_leader_project_text', true))):
                                    ?>
                                    <tr>
                                        <th><?php echo esc_html__('Project leader:', 'wicon'); ?></th>
                                        <td><?php echo get_post_meta(get_the_ID(), 'wicon_single_prefix_leader_project_text', true); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <?php 
                                $get_term2 = get_the_terms($post->ID, 'project_cats'); 
                                if($get_term2):
                                ?>
                                  <tr>
                                      <th><?php echo esc_html__('Category:', 'wicon'); ?></th>
                                      <td class="pcats"><?php                                          
                                          foreach ($get_term2 as $get_term2) :
                                              echo esc_attr($get_term2->name);
                                          endforeach;
                                          ?>                                          
                                      </td>
                                  </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                        <!-- ./info-->
                    </div>
                    <!-- ./left-->

                    <div class="col-md-6">
                        <div class="info description">
                            <h4 class="vk-title text-uppercase"><?php echo esc_html__('description', 'wicon'); ?></h4>
                            <p><?php the_content(); ?></p>
                        </div>
                        <!-- ./des-->
                    </div>
                    <!-- ./right-->
                </div>            
            </div>

          <?php endif; ?>
            
        
    </div>
    <?php
    if (true == get_theme_mod('project_single_show_related', true)) :
        wicon_get_related_project(get_the_ID());
    endif;
    ?>
</div>