<div class="animsition main-wrapper">
    <header class="vk-header vk-header-left-menu vk-header-home vk-header2">
        <nav class="vk-navbar navbar">
            <div class="vk-navbar-header navbar-header">
                <button type="button" class="navbar-toggle vk-navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#myNavbar">
                    <i class="toggle-icon"></i>
                </button>                
                <?php 
                if(get_theme_mod('display_cart', true)){
                if ( class_exists( 'WooCommerce' ) ) : ?>
                    <div class="shopping-cart hidden-md hidden-lg">
                        <a href="<?php echo get_permalink( wc_get_page_id( 'cart' ) ); ?>">
                            <i class="fa fa-shopping-basket" data-toggle="collapse" data-target="#shopping-cart-list"></i>
                            <?php global $woocommerce; ?>
                            <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                        </a>
                    </div>                    
                <?php endif; 
                }
                ?>
                <a class="vk-navbar-brand navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                    <div class="hidden-md hidden-lg">
                        <img src="<?php echo esc_html(get_theme_mod('logo_mobile')); ?>" alt="<?php esc_attr_e('logo', 'wicon') ?>">
                    </div>
                    <div class="hidden-xs hidden-sm">
                        <?php
                        if (!empty(get_theme_mod('logo_header2'))) :
                            ?>
                            <img src="<?php echo esc_url(get_theme_mod('logo_header2')); ?>" alt="wicon" class="logo">
                        <?php
                        else:
                            the_custom_logo();
                        endif;
                        ?>
                    </div>
                </a>
                <ul class="search-shopcart-button vk-list hidden-xs hidden-sm">
                    <li class="item-search">
                        <span class="btn-search hidden-xs hidden-sm" data-toggle="collapse"
                                  data-target="#box-search-header"><i class="fa fa-search"></i></span>
                    </li>
                    <?php 
                    if(get_theme_mod('display_cart', true)){
                    if ( class_exists( 'WooCommerce' ) ) : ?>
                        <li>
                            <a href="<?php echo get_permalink( wc_get_page_id( 'cart' ) ); ?>">
                                <div class="shopping-cart">
                                    <i class="fa fa-shopping-basket" data-toggle="collapse" data-target="#shopping-cart-list"></i>
                                    <?php global $woocommerce; ?>
                                    <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                                </div>
                            </a>
                        </li>
                    <?php endif; 
                    }
                    ?>
                </ul>
            </div>
            <div class="collapse navbar-collapse vk-navbar-collapse" id="menu">
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'primary',
                        'container' => 'ul',
                        'menu_class' => 'vk-navbar-nav',
                        'echo' => true,
                    )
                );
                ?>
                <?php
                if(get_theme_mod('display_search', true)){ ?>
                <div class="box-search-header collapse" id="box-search-header">
                    <div class="vk-input-group">
                        <?php
                        get_search_form();
                        ?>
                        <button class="vk-btn btn-search">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
                <?php } ?>
            </div>
            <div class="header-bot hidden-xs hidden-sm">
                <ul class="vk-list quick-address">
                    <?php
                    if (!empty(get_theme_mod('phone_header'))) :
                        ?>
                        <li><i class="fa fa-phone"></i><?php echo get_theme_mod('phone_header'); ?></li>
                    <?php
                    endif;

                    if (!empty(get_theme_mod('email_header'))) :
                        ?>
                        <li><i class="fa fa-envelope"></i><?php echo get_theme_mod('email_header'); ?></li>
                    <?php
                    endif;

                    if (!empty(get_theme_mod('time_header'))) :
                        ?>
                        <li><i class="fa fa-clock-o"></i><?php echo get_theme_mod('time_header'); ?></li>
                    <?php
                    endif;
                    ?>
                </ul>
            </div>
        </nav>
    </header>