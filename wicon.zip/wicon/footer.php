<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wicon
 */

?>
</div><!-- #content -->
<?php
$meta_page_footer_style = '';
if (is_page()) :
    global $post;
    $meta_page_footer_style = get_post_meta($post->ID, 'page-meta-footer', true);
endif;

$footer_layout = get_theme_mod('wicon_layout_footer', 'default');

if (is_page() && $meta_page_footer_style !== '' && $meta_page_footer_style !== 'default') :

    get_template_part('template-parts/main/footer/footer', $meta_page_footer_style);

else:
    get_template_part('template-parts/main/footer/footer', $footer_layout);

endif;
?>

<?php if (true == get_theme_mod('garenal_back_to_top', true)) : ?>
    <div id="btnscrollup">
        <div class="wapbtt"><i class="fa fa-chevron-up"></i></div>
    </div>
<?php endif; ?>
</div>
<?php wp_footer(); ?>

</body>
</html>
