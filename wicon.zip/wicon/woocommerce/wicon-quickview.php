<?php
global $post, $product, $woocommerce;
?>
<div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="row single-product-details">
        <?php if (has_post_thumbnail()) : ?>
        <div class="product-images col-lg-4 col-md-4 col-sm-3">
            <?php
            $wicon_attach_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false, '');
            $wicon_attach_count = count(get_children(array('post_parent' => $post->ID, 'post_mime_type' => 'image', 'post_type' => 'attachment')));
            ?>
            <div class="item wicon-product-gallery-img">
                <span itemprop="image"><?php echo get_the_post_thumbnail($post->ID, 'shop_single') ?></span>
            </div>

        </div>
        <div class="col-lg-8 col-md-8 col-sm-9 woocommerce">
            <?php
            else :
                echo '<div class="col-lg-12 col-md-12 col-sm-12 woocommerce">';
            endif; ?>
            <div class="summary entry-summary">
                <h3 itemprop="name" class="product_title entry-title">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h3>
                <?php
                /**
                 * wicon_woocommerce_single_product_summary hook
                 *
                 * @hooked woocommerce_template_single_price - 10
                 * @hooked woocommerce_template_single_excerpt - 20
                 * @hooked woocommerce_template_single_add_to_cart - 30
                 */
                do_action('wicon_wc_product_summary_quickview');

                wc_get_template('single-product/meta.php');
                ?>
            </div><!-- .summary -->
        </div>
    </div>

</div>
