<?php
$wicon_class = 'wicon-breadcrumbs clear';
$wicon_home  = esc_html__( 'Home', 'wicon' );
$wicon_blog  = esc_html__( 'Blog', 'wicon' );
$wicon_shop  = esc_html__( 'Shop', 'wicon' );

// Get the query & post information
global $post, $wp_query;

// Get post category
$wicon_category = get_the_category();

// Get product category
$wicon_product_cat = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );

if ( $wicon_product_cat ) {
	$wicon_tax_title = $wicon_product_cat->name;
}

$wicon_output = '';

// Build the breadcrums
$wicon_output .= '<ul class="' . esc_attr( $wicon_class ) . '">';

// Do not display on the homepage
if ( ! is_front_page() ) {

	if ( is_home() ) {

		// Home page
		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';

		$wicon_output .= '<li class="separator"> ' . $wicon_blog . ' </li>';

	} elseif ( function_exists( 'is_shop' ) && is_shop() ) {

		$wicon_output .= '<li class="item">' . $wicon_shop . '</li>';

	} else if ( function_exists( 'is_product' ) && is_product() || function_exists( 'is_cart' ) && is_cart() || function_exists( 'is_checkout' ) && is_checkout()  || function_exists( 'is_account_page' ) && is_account_page() ) {

		$wicon_output .= '<li class="item"><a href="' . esc_url( get_post_type_archive_link( 'product' ) ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_shop . '</a></li>';

		$wicon_output .= '<li class="item">' . get_the_title() . '</li>';

	} else if ( function_exists( 'is_product_category' ) && is_product_category() ) {

		$wicon_output .= '<li class="item"><a href="' . esc_url( get_post_type_archive_link( 'product' ) ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_shop . '</a></li>';

		$wicon_output .= '<li class="item">' . $wicon_tax_title . '</li>';

	} else if ( function_exists( 'is_product_tag' ) && is_product_tag() ) {

		$wicon_output .= '<li class="item"><a href="' . esc_url( get_post_type_archive_link( 'product' ) ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_shop . '</a></li>';

		$wicon_output .= '<li class="item">' . $wicon_tax_title . '</li>';

	} else if ( is_post_type_archive() ) {

		// Home page
		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';


		ob_start();
		post_type_archive_title();

		$wicon_output .= '<li class="item current">' . ob_get_clean() . '</li>';

	}
	else if ( is_single() ) {

		$post_type = get_post_type();
		// Home page
		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';


		if ( 'post' == $post_type && ! empty( $wicon_category ) ) :
			// First post category
			$wicon_output .= '<li class="item"><a href="' . esc_url( get_category_link( $wicon_category[0]->term_id ) ) . '" title="' . esc_attr( $wicon_category[0]->cat_name ) . '">' . $wicon_category[0]->cat_name . '</a></li>';
        endif;

		$wicon_output .= '<li class="item current">' . get_the_title() . '</li>';

	} else if ( is_archive() && is_tax() && ! is_category() && ! is_tag() ) {
		$tax_object = get_queried_object();

		// Home page
		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';


		if ( ! empty( $tax_object ) ) {
			$wicon_output .= '<li class="item current">' . esc_html( $tax_object->name ) . '</li>';
		}

	} else if ( is_category() ) {
		// Home page
		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';


		// Category page
		$wicon_output .= '<li class="item current">' . single_cat_title( '', false ) . '</li>';

	} else if ( is_page() ) {

		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';


		// Standard page
		if ( $post->post_parent ) {

			// If child page, get parents
			$wicon_anc = get_post_ancestors( $post->ID );

			// Get parents in the right order
			$wicon_anc = array_reverse( $wicon_anc );

			// Parent page loop
			foreach ( $wicon_anc as $wicon_ancestor ) :
				$wicon_parents = '<li class="item"><a href="' . esc_url( get_permalink( $wicon_ancestor ) ) . '" title="' . esc_attr( get_the_title( $wicon_ancestor ) ) . '">' . get_the_title( $wicon_ancestor ) . '</a></li>';

			endforeach;

			// Display parent pages
			$wicon_output .= $wicon_parents;

			// Current page
			$wicon_output .= '<li class="item current"> ' . get_the_title() . '</li>';

		} else {

			// Just display current page if not parents
			$wicon_output .= '<li class="item current"> ' . get_the_title() . '</li>';

		}

	} else if ( is_tag() ) {

		// Tag page
		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';


		// Get tag information
		$wicon_term_id  = get_query_var( 'tag_id' );
		$wicon_taxonomy = 'post_tag';
		$wicon_args     = 'include=' . $wicon_term_id;
		$wicon_terms    = get_terms( $wicon_taxonomy, $wicon_args );

		// Display the tag name
		if ( isset( $wicon_terms[0]->name ) )
			$wicon_output .= '<li class="item current">' . $wicon_terms[0]->name . '</li>';

	} elseif ( is_day() ) {

		// Year link
		$wicon_output .= '<li class="item"><a href="' . esc_url( get_year_link( get_the_time( 'Y' ) ) ) . '" title="' . esc_attr( get_the_time( 'Y' ) ) . '">' . get_the_time( 'Y' ) . esc_html__( ' Archives', 'wicon' ) . '</a></li>';


		// Month link
		$wicon_output .= '<li class="item"><a href="' . esc_url( get_month_link( get_the_time('Y'), get_the_time( 'm' ) ) ) . '" title="' . esc_attr( get_the_time( 'M' ) ) . '">' . get_the_time( 'M' ) . esc_html__( ' Archives', 'wicon' ) . '</a></li>';


		// Day display
		$wicon_output .= '<li class="item current"> ' . get_the_time('jS') . ' ' . get_the_time('M') . esc_html__( ' Archives', 'wicon' ) . '</li>';

	} else if ( is_month() ) {

		// Month Archive

		// Year link
		$wicon_output .= '<li class="item"><a href="' . esc_url( get_year_link( get_the_time( 'Y' ) ) ) . '" title="' . esc_attr( get_the_time( 'Y' ) ) . '">' . get_the_time( 'Y' ) . esc_html__( ' Archives', 'wicon' ) . '</a></li>';


		// Month display
		$wicon_output .= '<li class="item">' . get_the_time( 'M' ) . esc_html__( ' Archives', 'wicon' ) . '</li>';

	} else if ( is_year() ) {

		// Display year archive
		$wicon_output .= '<li class="item current">' . get_the_time('Y') . esc_html__( 'Archives', 'wicon' ) . '</li>';

	} else if ( is_author() ) {

		// Home page
		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';


		// Get the author information
		global $author;
		$wicon_userdata = get_userdata( $author );

		// Display author name
		$wicon_output .= '<li class="item current">' . esc_html__( 'Author: ', 'wicon' ) . '<a href="' . get_author_posts_url( $wicon_userdata->ID, $wicon_userdata->nice_name ) . '">' . $wicon_userdata->display_name . '</a></li>';

	} else if ( get_query_var( 'paged' ) ) {

		// Paginated archives
		$wicon_output .= '<li class="item current">' .  esc_html__( 'Page', 'wicon' ) . ' ' . get_query_var( 'paged', 'wicon' ) . '</li>';

	} else if ( is_search() ) {

		// Search results page
		$wicon_output .= '<li class="item current">' .  esc_html__( 'Keyword: ', 'wicon' ) . get_search_query() . '</li>';

	} elseif ( is_404() ) {

		// 404 page
		$wicon_output .= '<li class="item home"><a href="' . esc_url( get_home_url() ) . '" title="' . esc_attr( $wicon_home ) . '">' . $wicon_home . '</a></li>';

		$wicon_output .= '<li class="item current">' . esc_html__( 'Error 404', 'wicon' ) . '</li>';
	}

}

$wicon_output .= '</ul>';

echo wp_kses_post( $wicon_output );
