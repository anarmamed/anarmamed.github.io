<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package wicon
 */

get_header();

$wicon_single_layout = get_theme_mod('single_layouts', 'right');

$sidebar_single_class = '';
$col_single_class = array();

if ($wicon_single_layout === 'full'):
    $col_single_class[] = 'col-md-12 ';
else:
    if (!is_active_sidebar('sidebar-1')):
        $col_single_class[] = 'col-md-12 ';
    else:
        $col_single_class[] = 'col-md-9 ';
    endif;

endif;
if ($wicon_single_layout === 'left' && is_active_sidebar('sidebar-1')):
    $col_single_class[] = 'col-md-push-3 ';
    $sidebar_single_class = 'col-md-pull-9 ';
endif;
?>
    <div class="vk-banner vk-background-image-8">
        <div class="vk-background-overlay vk-background-black-1 _80"></div>
        <div class="container wrapper">
            <div class="page-heading">
                <?php
                the_title('<h1 class="page-title">', '</h1>');
                ?>
            </div>
        </div>
    </div>
    <div class="vk-breadcrumb">
        <nav class="container">
            <div class="row">
                <?php get_template_part('template-parts/breadcrumbs'); ?>
            </div>
        </nav>
    </div>
<?php
if (is_singular('pt_project')):
    while (have_posts()) : the_post();
        get_template_part('template-parts/main/project/single', 'project');
    endwhile;
else:
    ?>
    <div class="container single-blog-wicon">
        <div class="row">
            <div class="<?php echo esc_attr(implode(' ', $col_single_class)); ?>">
                <div id="primary" class="content-area">
                    <main id="main" class="site-main">
                        <?php
                        if (have_posts()):
                            while (have_posts()) : the_post();
                                if (is_singular('post')):
                                    get_template_part('template-parts/main/blog/single', 'blog');
                                else:
                                    the_content();
                                endif;
                            endwhile; // End of the loop.
                        endif;
                        ?>

                    </main><!-- #main -->
                </div><!-- #primary -->

            </div>
            <?php if ($wicon_single_layout !== 'full' && is_active_sidebar('sidebar-1')): ?>
                <div class="col-md-3 <?php echo esc_attr($sidebar_single_class); ?>">
                    <div class="">
                        <?php get_sidebar(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
endif;

get_footer();

