<?php
if (is_object($post) && get_post_meta($post->ID, 'meta-header1-trans', true) === "no") :
    $htrans_class = 'vk-header-relative';
endif;
?>
<div class="animsition main-wrapper">
    <header class="vk-header vk-header-home vk-header1 header-builder">
        <div class="vk-header-top hidden-xs">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 h-logo-bg hidden-sm hidden-xs">
                    </div>
                    <div class="col-md-10 col-sm-12 col-xs-12">
                        <?php 
                        if(get_theme_mod('display_cart', true)){
                        if ( class_exists( 'WooCommerce' ) ) : ?>
                            <div class="shopping-cart">
                                <i class="fa fa-shopping-basket" data-toggle="collapse" data-target="#shopping-cart-list"></i>
                                <?php global $woocommerce; ?>
                                <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                            </div>
                            <div class="shopping-cart-list collapse" id="shopping-cart-list">
                                <div class="vk-table woo-mini-cart">
                                    <ul class="vk-table-row">
                                        <li class="vk-table-data"><?php echo esc_html__('product', 'wicon'); ?></li>
                                    </ul>
                                    <?php
                                    if ( function_exists( 'woocommerce_mini_cart' ) ) :
                                        woocommerce_mini_cart();
                                    endif;
                                    ?>
                                </div>
                            </div>
                        <?php endif; 
                        } ?>
                            <?php
                            $config_social = get_theme_mod('config_social_header','');

                            $link_facebook = $link_twiter = $link_google = $link_youtube = $link_instagram= "";

                            if (!empty(get_theme_mod('facebook_header',''))) :
                                $link_facebook = get_theme_mod('facebook_header');
                            endif;
                            if (!empty(get_theme_mod('twitter_header',''))) :
                                $link_twiter = get_theme_mod('twitter_header');
                            endif;
                            if (!empty(get_theme_mod('google_header',''))) :
                                $link_google = get_theme_mod('google_header');
                            endif;

                            if (!empty(get_theme_mod('youtube_header',''))) :
                                $link_youtube = get_theme_mod('youtube_header');
                            endif;

                            if (!empty(get_theme_mod('instagram_header',''))) :
                                $link_instagram = get_theme_mod('instagram_header');
                            endif;
                             if (!empty(get_theme_mod('linkedin_header',''))) :
                                $link_instagram = get_theme_mod('linkedin_header');
                            endif;

                            if($config_social !=='') :
                                echo '<ul class="header-builder-social hidden-sm">';                                
                                foreach ($config_social as $item) :
                                    if ($item === "Facebook" && $link_facebook !=='') :
                                        echo '<li><a href="'.esc_url($link_facebook).'" target="_blank"><i class="fa fa-facebook"></i></a></li>';
                                    endif;

                                    if ($item === "Twitter" && $link_twiter !=='') :
                                        echo '<li><a href="'.esc_url($link_twiter).'" target="_blank"><i class="fa fa-twitter"></i></a></li>';
                                    endif;

                                    if ($item === "Google" && $link_google !=='') :
                                        echo '<li><a href="'.esc_url($link_google).'" target="_blank"><i class="fa fa-google-plus"></i></a></li>';
                                    endif;

                                    if ($item === "Youtube" && $link_youtube !=='') :
                                        echo '<li><a href="'.esc_url($link_youtube).'" target="_blank"><i class="fa fa-youtube"></i></a></li>';
                                    endif;

                                    if ($item === "Instagram" && $link_instagram !=='') :
                                        echo '<li><a href="'.esc_url($link_instagram).'" target="_blank"><i class="fa fa-instagram"></i></a></li>';
                                    endif;
                                    if ($item === "Linkedin" && $link_linkedin !=='') :
                                        echo '<li><a href="'.esc_url($link_linkedin).'" target="_blank"><i class="fa fa-linkedin"></i></a></li>';
                                    endif;

                                endforeach;
                                echo '</ul>';
                            endif;
                            ?>

                        <ul class="quick-address">
                            <?php if (!empty(get_theme_mod('phone_header'))) :
                                echo '<li><i class="fa fa-phone" aria-hidden="true"></i>'.esc_html(get_theme_mod('phone_header')).'</li>';
                            endif;

                            if (!empty(get_theme_mod('email_header'))) :
                                echo '<li><i class="fa fa-envelope" aria-hidden="true"></i>'.esc_html(get_theme_mod('email_header')).'</li>';
                            endif;

                            if (!empty(get_theme_mod('site_address'))) :
                                echo '<li><i class="fa fa-map-marker" aria-hidden="true"></i>'.esc_html(get_theme_mod('site_address')).'</li>';
                            endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="h-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 hb-logo h-logo-bg col-sm-3 col-xs-4">
                        <a href="<?php echo esc_url(home_url('/')); ?>">
                            <img src="<?php echo esc_url(get_theme_mod('logo_header_builder')); ?>" alt="<?php esc_attr_e('logo', 'wicon') ?>" >
                        </a>
                    </div>

                    <div class="navbar-header hidden-lg hidden-md col-sm-9 col-xs-8">
                            <button type="button" class="navbar-toggle vk-navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#myNavbar">
                                <i class="toggle-icon"></i>
                            </button>
                        </div>
                    <nav class="col-md-9 col-sm-12 col-xs-12 builder-nav">
                        <div class="collapse navbar-collapse vk-navbar-collapse" id="menu">
                            <?php
                            wp_nav_menu(
                                array(
                                    'theme_location' => 'primary',
                                    'container' => 'ul',
                                    'menu_class' => 'vk-navbar-nav',
                                    'echo' => true,
                                )
                            );
                            ?>
                        </div>
                    </nav>
                    <?php
                    if(get_theme_mod('display_search', true)){ ?>
                    <div data-toggle="collapse" data-target="#box-search-header" aria-expanded="false"
                         aria-controls="collapseSearch" class="h-search col-md-1 hidden-sm hidden-xs">
                        <i class="fa fa-search" aria-hidden="true"></i>
                    </div>
                    <div class="box-search-header collapse" id="box-search-header">
                        <div class="vk-input-group">
                            <?php get_search_form(); ?>
                            <button class="vk-btn btn-search"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                    <!--./box-search-header-->
                    <?php } ?>
                </div>
            </div>
        </div>
    </header>

