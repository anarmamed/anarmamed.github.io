<?php
/*
    Template Name: BlogGrid
*/

get_header();

$wicon_blog_layout = get_theme_mod('blog_layouts', 'left');

$sidebar_blog_class = '';
$col_blog_class = array();

if ($wicon_blog_layout === 'full') :
    $col_blog_class[] = 'col-md-12 ';
else:
    if (!is_active_sidebar('sidebar-1')) :
        $col_blog_class[] = 'col-md-12 ';
    else:
        $col_blog_class[] = 'col-md-9 ';
    endif;

endif;
if ($wicon_blog_layout === 'left' && is_active_sidebar('sidebar-1')) :
    $col_blog_class[] = 'col-md-push-3 ';
    $sidebar_blog_class = 'col-md-pull-9';
endif;
?>
    <section class="vk-content blog-gird-wicon">
    <div class="vk-banner vk-background-image-3">
        <div class="vk-background-overlay vk-background-black-1 _80"></div>
        <div class="container wrapper">
            <div class="page-heading">
                <?php the_title('<h1 class="page-title">', '</h1>'); ?>
            </div>
        </div>
    </div>
    <!--./vk-banner-->
    <div class="vk-breadcrumb">
        <nav class="container">
            <div class="row">
                <?php get_template_part('template-parts/breadcrumbs'); ?>
            </div>
        </nav>
    </div>
    <!--./vk-breadcrumb-->
    <div class="" data-example-id="media-alignment">
        <div class="vk-blog-wrapper vk-blog-grid">
            <!------ BEGIN BLOG WRPPER ------>
            <div class="container">
                <div class="row">
                    <div class="blog-list clearfix">
                        <!-- BLOG CONTENT -->
                        <div class="<?php echo esc_attr(implode(' ', $col_blog_class)); ?>">
                            <div class=" blog-content">
                                <div class="row">
                                    <?php
                                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                                    $arr_post = array(
                                        'post_type' => 'post',
                                        'order' => 'desc',
                                        'paged' => $paged
                                    );

                                    $query_post = new WP_Query($arr_post);

                                    if ($query_post->have_posts()) : while ($query_post->have_posts()) : $query_post->the_post();
                                        ?>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="content-box">
                                                <?php if (has_post_thumbnail()) : ?>
                                                    <div class="vk-img-frame">
                                                        <a class="vk-img" href="<?php the_permalink(); ?>">
                                                            <?php the_post_thumbnail('wicon-blog-thumb'); ?>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>

                                                <div class="content">
                                                    <a href="<?php the_permalink(); ?>">
                                                        <h4 class="vk-text-uppercase"><?php the_title(); ?></h4>
                                                    </a>
                                                    <div class="vk-divider"></div>
                                                    <?php
                                                    if (has_excerpt()) :
                                                        the_excerpt();
                                                    endif;
                                                    ?>
                                                    <div class="vk-buttons">
                                                        <a href="<?php the_permalink(); ?>" class="text-uppercase vk-btn-readmore"><?php echo esc_html__('read more', 'wicon'); ?>
                                                            <i class="fa fa-long-arrow-right"></i></a>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    endwhile;
                                    endif;
                                    wp_reset_postdata();
                                    ?>
                                </div>
                                <!-- PAGE NUMBER -->
                                <nav class="box-pagination text-center">
                                    <?php
                                    global $query_args;

                                    $big = 999999999; // need an unlikely integer

                                    echo paginate_links(array(
                                        'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                                        'format' => '?paged=%#%',
                                        'current' => max(1, get_query_var('paged')),
                                        'total' => $query_post->max_num_pages,
                                        'prev_next' => True,
                                        'prev_text' => esc_html__('Prev', 'wicon'),
                                        'next_text' => esc_html__('Next', 'wicon')
                                    ));
                                    ?>
                                </nav>

                            </div>
                        </div>

                        <!-- BLOG SIDEBAR -->
                        <?php if ($wicon_blog_layout !== 'full' && is_active_sidebar('sidebar-1')) : ?>
                            <div class="col-md-3 sidebar-blog-list <?php echo esc_attr($sidebar_blog_class); ?>">
                                <?php get_sidebar(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!------ END BLOG WRAPPER ------>
            </div>
        </div>
    </div>
<?php
get_footer();
?>