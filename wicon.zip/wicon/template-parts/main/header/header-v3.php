<div class="animsition main-wrapper">
    <header class="vk-header vk-header-one-page vk-header-transparent vk-header-home vk-header3">
        <nav class="vk-navbar  navbar">
            <div class="container">
                <div class="vk-navbar-header navbar-header">
                    <button type="button" class="navbar-toggle vk-navbar-toggle collapsed" data-toggle="collapse"
                            data-target="#myNavbar">
                        <i class="toggle-icon"></i>
                    </button>                    
                    <?php 
                    if(get_theme_mod('display_cart', true)){
                    if ( class_exists( 'WooCommerce' ) )  : ?>
                        <div class="shopping-cart hidden-md hidden-lg">
                            <i class="fa fa-shopping-basket" data-toggle="collapse" data-target="#shopping-cart-list"></i>
                            <?php global $woocommerce; ?>
                            <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                        </div>                        
                    <?php endif; 
                    } ?>
                    <a class="vk-navbar-brand navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                        <?php
                        if (!empty(get_theme_mod('logo_header3'))) :
                            ?>
                            <img src="<?php echo esc_url(get_theme_mod('logo_header3')); ?>" alt="wicon"
                                 class="<?php esc_attr_e('logo', 'wicon') ?>">
                            <?php
                        else:
                            the_custom_logo();
                        endif;
                        ?>
                    </a>
                    
                    <?php 
                    if(get_theme_mod('display_cart', true)){
                    if ( function_exists( 'woocommerce_mini_cart' ) )  : ?>
                        <div class="shopping-cart-list collapse" id="shopping-cart-list">
                            <div class="vk-table woo-mini-cart">
                                <ul class="vk-table-row">
                                    <li class="vk-table-data"><?php echo esc_html__('product', 'wicon'); ?></li>
                                </ul>
                                <?php woocommerce_mini_cart(); ?>
                            </div>
                        </div>
                        
                    <?php endif; 
                    } ?>

                </div>
                <!--./vk-navbar-header-->
                <div class="collapse navbar-collapse vk-navbar-collapse" id="menu">
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'primary',
                            'container' => 'ul',
                            'menu_class' => 'vk-navbar-nav navbar-right',
                            'echo' => true,
                        )
                    );
                    ?>
                    <!--./vk-navbar-nav-->
                    <?php
                    if(get_theme_mod('display_search', true)){ ?>
                    <div class="box-search-header collapse" id="box-search-header">
                        <div class="vk-input-group">
                            <?php get_search_form(); ?>
                            <button class="vk-btn btn-search">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>  
                    <?php } ?>                 
                </div>                
            </div>
            <!--./container-->
        </nav>
        <!--./vk-navbar-->
    </header>
