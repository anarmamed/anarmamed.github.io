<?php
if (is_object($post) && get_post_meta($post->ID, 'meta-header1-trans', true) === "no") :
    $htrans_class = 'vk-header-relative';
endif;
?>
<div class="main-wrapper">
    <header class="vk-header header-luxury">      
        
        <div class="h-luxyry-main">
            <div class="container">
                <div class="row">
                  <div class="col-md-2 col-sm-3 lux-logo">
                    <?php if (!empty(get_theme_mod('logo_header_luxury'))) : ?>
                      <a href="<?php echo esc_url(home_url('/')); ?>">
                        <img src="<?php echo esc_url(get_theme_mod('logo_header_luxury')); ?>" alt="<?php echo esc_attr( get_bloginfo('description') ); ?>"></a>
                      <?php
                        else:
                            the_custom_logo();
                        endif;
                        ?>                    
                  </div>
                  <div class="col-md-8 col-sm-12 h-luxyry-menu">
                    <button type="button" class="navbar-toggle vk-navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
                                <i class="toggle-icon"></i>
                            </button>
                    <div class="collapse navbar-collapse vk-navbar-collapse" id="menu">
                            <?php
                            wp_nav_menu(
                                array(
                                    'theme_location' => 'primary',
                                    'container' => 'ul',
                                    'menu_class' => 'vk-navbar-nav',
                                    'echo' => true,
                                )
                            );
                            ?>
                        </div>                    
                  </div>
                  <div class="col-md-2 right-header col-sm-9 col-6">
                    <?php 
                    if(get_theme_mod('display_cart', true)){
                    if ( class_exists( 'WooCommerce' ) ) : ?>
                            <div class="h-shopping-cart">
                                <i class="fa fa-shopping-basket" data-toggle="collapse" data-target="#shopping-cart-list"></i>
                                <?php global $woocommerce; ?>
                                <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
                            </div>
                            <div class="shopping-cart-list collapse" id="shopping-cart-list">
                                <div class="vk-table woo-mini-cart">
                                    <ul class="vk-table-row">
                                        <li class="vk-table-data"><?php echo esc_html__('product', 'wicon'); ?></li>
                                    </ul>
                                    <?php
                                    if ( function_exists( 'woocommerce_mini_cart' ) ) :
                                        woocommerce_mini_cart();
                                    endif;
                                    ?>
                                </div>
                            </div>
                    <?php endif; 
                    }   
                    ?>                        
                    <?php
                    if(get_theme_mod('display_search', true)){
                        echo '<div class="header-search-wrap-popup">';
                        echo '<span class="icon-header-search"><i class="fa fa-search" aria-hidden="true"></i></span>';
                            echo '<div class="inner-search-wrap">';
                                get_search_form();
                            echo '</div>';
                        echo '</div>';
                        echo '<div class="close-search"></div>';
                    }                         
                    ?>
                  </div>
                </div>
            </div>
        </div>
    </header>

