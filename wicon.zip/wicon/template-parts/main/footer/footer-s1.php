<?php
if (!is_404()) :
    if (is_object($post) && get_post_meta($post->ID, 'custom-header', true) == "Header 2") :
        echo "<div class='col-md-12'>";
    endif;
endif;

?>
    <footer class="vk-footer footer-layout-1">

        <div class="container">
            <?php
            if (!empty(get_theme_mod('site_address')) || !empty(get_theme_mod('phone_header')) || !empty(get_theme_mod('email_header'))) : ?>
                <div class="row">
                    <div class="footer-top-address">
                        <?php
                        if (!empty(get_theme_mod('site_address'))) :
                            echo '<div class="col-md-4"><div class="footer-address-item">';
                            echo '<i class="uni-icomoon icon-placeholder color-primary" aria-hidden="true"></i><div>'.esc_html__('Address','wicon').'</div><span class="info-mod">' . esc_html(get_theme_mod('site_address')) . '</span></div></div>';
                        endif;
                        if (!empty(get_theme_mod('phone_header'))) :
                            echo '<div class="col-md-4"><div class="footer-address-item"><i class="uni-icomoon icon-smartphone color-primary" aria-hidden="true"></i><div>'.esc_html__('Phone','wicon').'</div><span class="info-mod">' . esc_html(get_theme_mod('phone_header')) . '</span></div></div>';
                        endif;

                        if (!empty(get_theme_mod('email_header'))) :
                            echo '<div class="col-md-4"><div class="footer-address-item"><i class="uni-icomoon icon-email color-primary" aria-hidden="true"></i><div>'.esc_html__('Email','wicon').'</div><span class="info-mod">' . esc_html(get_theme_mod('email_header')) . '</span></div></div>';
                        endif;
                        ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (is_active_sidebar('sidebar-footer1') || is_active_sidebar('sidebar-footer2') || is_active_sidebar('sidebar-footer3') || is_active_sidebar('sidebar-footer4')) : ?>
                <div class="row">
                    <?php if (is_active_sidebar('sidebar-footer1')) : ?>
                        <div class="col-md-4">
                            <?php dynamic_sidebar('sidebar-footer1'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('sidebar-footer2')) : ?>
                        <div class="col-md-4">
                            <?php dynamic_sidebar('sidebar-footer2'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('sidebar-footer3')) : ?>
                        <div class="col-md-4">
                            <?php dynamic_sidebar('sidebar-footer3'); ?>
                        </div>
                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </div>

        <?php if (is_active_sidebar('sidebar-footer5')) : ?>
            <div class="copyright">
                <?php dynamic_sidebar('sidebar-footer5'); ?>

            </div>
        <?php else : ?>
            <div class="copyright">

                <a href="<?php echo esc_url(('https://wordpress.org/')); ?>"><?php
                    /* translators: %s: CMS name, i.e. WordPress. */
                    printf(esc_html__('Proudly powered by %s', 'wicon'), 'WordPress');
                    ?></a>
                <span class="sep"> | </span>
                <?php
                /* translators: 1: Theme name, 2: Theme author. */
                printf(esc_html__('Theme: %1$s by %2$s.', 'wicon'), 'wicon', '<a href="' . esc_url('https://themeforest.net/user/ava-themes') . '" rel="nofollow">Ava Themes</a>');
                ?>
            </div>
        <?php
        endif;
        ?>
    </footer>
<?php
if (!is_404()) :
    if (is_object($post) && get_post_meta($post->ID, 'custom-header', true) === "Header 2") :
        echo "</div>";
    endif;
endif;
?>