<?php
/*
 * Template Name: Project Grid*/
get_header();
?>

<section class="vk-content">
    <div class="vk-banner vk-background-image-3">
        <div class="vk-background-overlay vk-background-black-1 _80"></div>
        <div class="container wrapper">
            <div class="page-heading">
                <?php the_title('<h1 class="page-title">', '</h1>'); ?>
            </div>
        </div>
    </div>
    <!--./vk-banner-->

    <div class="vk-breadcrumb">
        <nav class="container">
            <div class="row">
                <ul>
                    <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html__('home', 'wicon'); ?></a>
                    </li>

                    <li class="active"><?php echo the_title(); ?></li>
                </ul>
            </div>
        </nav>
    </div>
    <!--./vk-breadcrumb-->
    <div class="vk-page vk-page-project vk-page-project-grid vk-space x-large">
        <div class="container">
            <nav class="box-filter text-center clearfix">
                <ul class="vk-filter vk-filter-button hidden-xs hidden-sm">

                    <li class="data-filter" data-filter="*">all</li>
                    <?php
                    $term_tax = get_terms(array(
                        'taxonomy' => 'project_cats',
                        'hide_empty' => false,
                    ));
                    if (!is_wp_error($term_tax)) :
                        foreach ($term_tax as $item):
                            ?>
                            <li class="data-filter" data-filter=".data-<?php echo esc_attr($item->slug); ?>"><?php echo esc_attr($item->name); ?></li>
                        <?php
                        endforeach;
                    endif;
                    ?>
                </ul>
                <!--./vk-filter-->

                <select class="vk-filter vk-filter-button form-control hidden-md hidden-lg">
                    <option class="data-filter" value="*">all</option>
                    <?php
                    if (!is_wp_error($term_tax)) :
                        foreach ($term_tax as $item2):
                            ?>
                            <option class="data-filter"
                                    value=".data-<?php echo esc_attr($item2->slug); ?>"><?php echo esc_attr($item2->name); ?></option>
                        <?php endforeach;
                    endif;
                    ?>
                </select>
            </nav>

            <div class="row">
                <div class="vk-project-grid clearfix vk-masonry-layout">
                    <?php
                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    $args = array(
                        'post_type' => 'pt_project',
                        'posts_per_page' => 6,
                        'order' => 'desc',
                        'paged' => $paged
                    );
                    $query = new WP_Query($args);
                    if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
                        ?>
                        <div class="col-md-4 col-sm-6 col-xs-12 item data-<?php
                        $get_term = get_the_terms($post->ID, 'project_cats');
                        foreach ($get_term as $get_term) :
                            echo esc_attr($get_term->slug);
                        endforeach;
                        ?>">
                            <div class="vk-project vk-project-grid-item">
                                <?php if (has_post_thumbnail()) : ?>
                                    <div class="vk-img-frame">
                                        <a href="<?php the_permalink(); ?>" class="vk-img">
                                            <?php the_post_thumbnail('wicon-blog-thumb'); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                <div class="content-hidden">
                                    <h4 class="vk-title text-uppercase">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h4>
                                </div>
                            </div>
                        </div>
                    <?php
                    endwhile;
                    endif;
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
            <!--./row-->

            <div class="vk-buttons text-center">
                <a href="#" class="vk-btn vk-btn-transparent text-uppercase vk-btn-readmore">
                    load more
                    <i class="fa fa-long-arrow-down"></i></a>
            </div>
            <!--./vk-buttons-->
        </div>
        <!--./container-->
    </div>
    <!--./vk-page-->
</section>
<!--./content-->

<?php
get_footer();
?>
