'use strict';
function uniAnimate(x) {
    jQuery(x).each(function(){
        var animate_style = jQuery(this).attr('class');
        var h2class = jQuery(this).children().attr('class');
        jQuery(this).children().addClass(animate_style + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
            jQuery(this).removeClass();
            jQuery(this).addClass(h2class);

        });
    });
};
jQuery( document ).ready(function() {
    jQuery('.header-search-wrap-popup').click(function () {
            jQuery(this).find('.inner-search-wrap').addClass('fix-serach');
            jQuery(this).find('.inner-search-wrap').css({"display" : "block"});
            jQuery(this).find('.search-form').addClass('visible');
            jQuery('.close-search').css({"display" : "block"});
        });
        jQuery('.close-search').click(function() {
                jQuery(this).css({"display" : "none"});
                jQuery('.inner-search-wrap').removeClass('fix-serach');
                jQuery('.inner-search-wrap').css({"display" : "none"});
                jQuery('.search-form').removeClass('visible');
        });

    jQuery('.uni-wicon-slider').each(function () {
        jQuery(this).slick({
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="ti-angle-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="ti-angle-left"></i></button>',
        });
    });
    jQuery('.box-number').each(function(){
        statsCounterAnimation(this);
    });

    function statsCounterAnimation(element) {
        var inView = false;

        if (isScrolledIntoView(element)) {
            if (inView) {
                return;
            }
            inView = true;
            jQuery(element).each(function() {
                jQuery(this).animateNumber({ number: jQuery(this).data('value'), easing: 'easeOutExpo'}, 1500);
            });
        }
        jQuery(window).scroll(function() {
            if (isScrolledIntoView(element)) {
                if (inView) {
                    return;
                }
                inView = true;
                jQuery(element).each(function() {
                    jQuery(this).animateNumber({ number: jQuery(this).data('value'), easing: 'easeOutExpo'}, 1500);
                });
            }
        });
    }
    function isScrolledIntoView(elem) {
        var docViewTop = jQuery(window).scrollTop();
        var docViewBottom = docViewTop + jQuery(window).height();

        var elemTop = jQuery(elem).offset().top;
        var elemBottom = elemTop + jQuery(elem).height();

        return ((elemTop <= docViewBottom) && (elemBottom >= docViewTop));
    }
    /*Animate slider*/
    jQuery('.nextend-arrow-next').click(function(e){
        e.preventDefault();
        uniAnimate('.n2-ss-layer.unianimated');
    });
    jQuery('.nextend-arrow-previous').click(function(e){
        e.preventDefault();
        uniAnimate('.n2-ss-layer.unianimated');
    });
    jQuery('.n2-ss-control-bullet').click(function(e){
        e.preventDefault();
        uniAnimate('.n2-ss-layer.unianimated');
    });
    jQuery('.n2-ss-layer.unianimated').each(function(){
        var animate_style_f = jQuery(this).attr('class');
        jQuery(this).children().addClass(animate_style_f + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
            jQuery(this).removeClass(animate_style_f + ' animated');
        });
    });

    jQuery(".firstword").html(function(){
        var text= jQuery(this).text().trim().split(" ");
        var first = text.shift();
        return (text.length > 0 ? "<span class='vk-text-color-yellow-1'>"+ first + "</span> " : first) + text.join(" ");
    });

    ( function() {
        jQuery(window).scroll(function() {
            if (jQuery(window).scrollTop() >= 250) {
                jQuery('.page-id-2760 .vk-header-one-page').addClass('fixed-header', 1000);

            }
            else {
                jQuery('.page-id-2760 .vk-header-one-page').removeClass('fixed-header');

            }
        });
    })();
    jQuery('.menu-toggle').on('click', function () {
        jQuery(this).next().find('.wicon-site-header-menu').toggleClass("toggled-on");

    });
    function wiconInitMainNavigation( container ) {
        var dropdownToggle = jQuery( '<button />', {
            'class': 'dropdown-toggle',
            'aria-expanded': false
        } );
        container.find( '.menu-item-has-children > a' ).after( dropdownToggle );
        container.find( '.current-menu-ancestor > button' ).addClass( 'toggled-on' );
        container.find( '.menu-item-has-children' ).attr( 'aria-haspopup', 'true' );
        container.find( '.dropdown-toggle' ).on('click', function( e ) {
            var _this            = jQuery( this );
            e.preventDefault();
            _this.toggleClass( 'toggled-on' );
            _this.parent().toggleClass( 'mwc-on' );
            _this.next( '.children, .sub-menu' ).toggleClass( 'toggled-on' );
            _this.attr( 'aria-expanded', _this.attr( 'aria-expanded' ) === 'false' ? 'true' : 'false' );

        } );
    }
    wiconInitMainNavigation( jQuery( '.wicon-site-header-menu' ) );
});

/*animation scroll page*/
var AnimationScrollPage = function () {
    var _initInstances = function () {
        jQuery('.animation').waypoint(function (direction) {
            jQuery(this).addClass('animation-active');
        }, {
            offset: '100%',
            triggerOnce: true
        });
    };

    return {
        init: function () {
            _initInstances();
        }
    };
}();


/*slider*/
var Slider = function () {
    var singleProjectSlider = function () {
        jQuery('.vk-slider-project .slider-for').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
            fade: true,
            asNavFor: '.slider-nav',
            focusOnSelect: true,
        });
        jQuery('.vk-slider-project .slider-nav').slick({
            slidesToShow: 6,
            slidesToScroll: 1,
            asNavFor: '.slider-for',
            focusOnSelect: true,
            arrows: false,
            responsive: [{

                breakpoint: 992,
                settings: {
                    slidesToShow: 3,
                }

            }]
        });
    };

    var singleProductSlider = function () {
        jQuery('.vk-slider-shop .slider-for').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true,
            arrows: false,
            asNavFor: '.slider-nav',
            adaptiveHeight: true,
        });
        jQuery('.vk-slider-shop .slider-nav').slick({
            slidesToShow: 5,
            slidesToScroll: 1,
            asNavFor: '.slider-for',
            focusOnSelect: true,
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
        });
    };

    var imageSlider = function () {
        jQuery('.vk-slick-slider').slick({
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
            centerPadding: 0,
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        arrows: true,
                    }

                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        arrows: false,
                        centerMode: true,
                        centerPadding: '50px',
                    }

                }]
        });
    };

    var homepageSlider = function () {

        jQuery('.recent-blog-slider').slick({
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
            slidesToShow: 2,
            dots: true,
            dotsClass: 'vk-arrow-dots',
            responsive: [{

                breakpoint: 992,
                settings: {
                    slidesToShow: 1,
                    arrows: false
                }

            }]
        })
            .on('setPosition', function (event, slick) {
                arrowDotNav();
            });


    };

    var aboutPageSlider = function () {
        jQuery('.customer-slider').slick({
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
            adaptiveHeight: true,
            responsive: [{
                breakpoint: 992,
                settings: {
                    arrows: false
                }

            },{
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                }

            }]
        });
    };

    var homeShopSlider = function () {

        jQuery('.vk-list-client-shop > .vk-list').slick({
            slidesToShow: 6,
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [{
                breakpoint: 992,
                settings: {
                    slidesToShow: 3,
                }

            },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                    }

                }]
        });
    };

    var arrowDotNav = function () {
        var arrowDots = jQuery('.vk-arrow-dots');
        if (arrowDots.length > 0) {
            var dots = arrowDots.find('>li');
            var numDots = dots.length;
            dots.css('width', 'calc(100% / ' + numDots + ')')

        }
    };

    var homeOnePage = function () {

        var currentWidth = jQuery(window).outerWidth();

        if (currentWidth >= 768) {

            jQuery('.slick-slider-one-page').addClass('_pc');

            if (jQuery('.slick-slider-one-page.slick-slider').length == 1 && $('.slick-slider-one-page._mobile').length == 1) {
                jQuery('.slick-slider-one-page').slick('destroy');
                jQuery('.slick-slider-one-page').removeClass('_mobile');
            }

            if (jQuery('.slick-slider-one-page._pc').length == 1 && $('.slick-slider-one-page.slick-slider').length == 0) {

                jQuery('.slick-slider-one-page').slick({
                    nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
                    prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
                    slidesToShow: 3,
                    rows: 2,
                    responsive: [
                        {
                            breakpoint: 991,
                            settings: {
                                slidesToShow: 2,
                            }
                        }],
                });
            }

        }

        if (currentWidth < 768) {

            jQuery('.slick-slider-one-page').addClass('_mobile');

            if (jQuery('.slick-slider-one-page.slick-slider').length == 1 && $('.slick-slider-one-page._pc').length == 1) {
                jQuery('.slick-slider-one-page').slick('destroy');
                jQuery('.slick-slider-one-page').removeClass('_pc');
            }
            if (jQuery('.slick-slider-one-page._mobile').length == 1 && $('.slick-slider-one-page.slick-slider').length == 0) {
                console.log('MB');
                jQuery('.slick-slider-one-page').slick({
                    nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
                    prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
                    slidesToShow: 1,
                    rows: 1,
                });
            }
        }
        if (currentWidth >= 1068){
            jQuery('.slick-slider-left-menu').addClass('_pc');

            if (jQuery('.slick-slider-left-menu.slick-slider').length == 1 && $('.slick-slider-left-menu._mobile').length == 1) {
                jQuery('.slick-slider-left-menu').slick('destroy');
                jQuery('.slick-slider-left-menu').removeClass('_mobile');
            }

            if (jQuery('.slick-slider-left-menu._pc').length == 1 && $('.slick-slider-left-menu.slick-slider').length == 0) {

                jQuery('.slick-slider-left-menu').slick({
                    nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
                    prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
                    slidesToShow: 3,
                    rows: 2,
                    responsive: [
                        {
                            breakpoint: 1291,
                            settings: {
                                slidesToShow: 2,
                            }
                        }],
                });
            }
        }

    };

    var homeOnePageExtra = function () {
        jQuery('.vk-slider-testimonial').slick({
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="ti-angle-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="ti-angle-left"></i></button>',
            adaptiveHeight: true
        });

        jQuery('.vk-pricing-table-slider').slick({
            arrows: false,
            adaptiveHeight: true,
            slidesToShow: 4,
            responsive: [
                {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 2,
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                    }
                },
            ],
        });

    }

    var homeSlider = function(){

        var slider = jQuery('.vk-baner-slider');

        var imageArrow = function(){
            var itemSlider = slider.find('.slick-slide');
            var itemSliderCurrent = slider.find('.slick-slide.slick-current');
            var totalSlider = itemSlider.length;
            var imageNext='';
            var imagePrev='';

            if(itemSliderCurrent.attr('data-slick-index') == 0){
                imagePrev = jQuery(itemSlider.last()).css('background-image');
                imageNext = jQuery(itemSliderCurrent).next().css('background-image');
            }

            else if(itemSliderCurrent.attr('data-slick-index') == totalSlider - 1){
                imageNext = jQuery(itemSlider.first()).css('background-image');
                imagePrev = jQuery(itemSliderCurrent).prev().css('background-image');
            }
            else{
                imageNext = jQuery(itemSliderCurrent).next().css('background-image');
                imagePrev = jQuery(itemSliderCurrent).prev().css('background-image');
            }

            return{
                imageNext: imageNext,
                imagePrev: imagePrev,
            }
        }

        /*slick initial*/
        slider.on('init', function(event, slick){

            /*option slider fade: false*/
            var imageNext = jQuery('.slick-slide.slick-current').next().css('background-image');
            var imagePrev = jQuery('.slick-slide.slick-current').prev().css('background-image');

            jQuery(this).find('.vk-arrow.next .image-preview-thumbnail').css('background-image',imageNext);
            jQuery(this).find('.vk-arrow.prev .image-preview-thumbnail').css('background-image',imagePrev);

            var $firstAnimatingElements = jQuery('.slick-slide').find('[data-animation]');
            doAnimations($firstAnimatingElements);
        });

        slider.on('beforeChange', function(e, slick, currentSlide, nextSlide) {
            var $animatingElements = jQuery('.slick-slide[data-slick-index="' + nextSlide + '"]').find('[data-animation]');
            doAnimations($animatingElements);
            console.log(currentSlide,nextSlide)
        });
        slider.slick({
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="icon ti-angle-right"></i><span class="image-preview-thumbnail"></span></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="icon ti-angle-left"></i><span class="image-preview-thumbnail"></span></button>',
            dotsClass:'vk-list vk-dots-nav',
            dots: true,
            fade:false,
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 1,
                        arrows:false,
                    }
                }
            ],
        });

        /*after Change slide change*/
        slider.on('afterChange', function(event, slick, currentSlide){
            /*option slider fade: false*/
            var imageNext = jQuery('.slick-slide.slick-current').next().css('background-image');
            var imagePrev = jQuery('.slick-slide.slick-current').prev().css('background-image');

            jQuery(this).find('.vk-arrow.next .image-preview-thumbnail').css('background-image',imageNext);
            jQuery(this).find('.vk-arrow.prev .image-preview-thumbnail').css('background-image',imagePrev);
        });

        function doAnimations(elements) {
            var animationEndEvents = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
            elements.each(function() {
                var $this = $(this);
                var $animationDelay = $this.data('delay');
                var $animationType = 'animated ' + $this.data('animation');
                $this.css({
                    'animation-delay': $animationDelay,
                    '-webkit-animation-delay': $animationDelay,
                    'display':'inline-block',
                });
                $this.addClass($animationType).one(animationEndEvents, function() {
                    $this.removeClass($animationType);
                });
            });
        }

    }

    var sortList = function ($) {
        jQuery(".vk-shop-item .vk-list-inline").each(function(){
            jQuery(this).html(jQuery(this).children('li').sort(function(a, b){
                return (jQuery(b).data('position')) < (jQuery(a).data('position')) ? 1 : -1;
            }));
        });
    }

    var _initInstances = function () {
        imageSlider();
        homepageSlider();
        singleProjectSlider();
        aboutPageSlider();
        homeShopSlider();
        singleProductSlider();
        homeOnePage();
        homeOnePageExtra();
        homeSlider();
        sortList();
    };

    return {
        init: function () {
            _initInstances();
        },
        responsive: function () {
            homeOnePage();
        }
    };
}();

/*masonry item*/
var MasonryItem = function () {
    var masonry_item = ['.vk-masonry-layout',];
    var slider_filter = ['.vk-slider-filter',];
    var listFilterFix = ['.vk-filter-fix'];

    var buttonFilter = '.vk-filter';
    var buttonFilterDefault = '.vk-filter-button';
    var buttonFilterFix = '.vk-filter-button-fix';

    var sliderFilter = function () {
        jQuery('.slick-slider-homepage').slick({
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
            slidesToShow: 3,
            rows: 2,
            responsive: [
                {
                    breakpoint: 1200,
                    settings: {
                        arrows: false,
                    }
                }, {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 2,
                        arrows: false,
                    }
                }, {

                    breakpoint: 768,
                    settings: "unslick",

                }],
        });

        jQuery('.slick-slider-project-left-menu').slick({
            nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
            prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
            slidesToShow: 3,
            rows: 2,
            responsive: [
                {
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 2,
                    }
                }, {

                    breakpoint: 768,
                    settings: "unslick",

                }],
        });


        jQuery(slider_filter.toString()).isotope({
            filter: '.all',
        });
        jQuery(buttonFilterDefault)
            .on('click', ' li', function () {
                var filterValue = jQuery(this).attr('data-filter');
                jQuery(slider_filter.toString()).isotope({
                    filter: filterValue,
                });

                return false;
            });
    };

    var sliderResponsiveFilter = function () {

        var currentWidth = jQuery(window).outerWidth();

        if (currentWidth > 992 && jQuery('.vk-slider-what-we-do.slick-slider').length == 0) {
            jQuery('.vk-slider-what-we-do').removeClass('vk-filter-fix');
            jQuery('.vk-slider-what-we-do .item').css('display', 'block');
            jQuery('.vk-slider-what-we-do').slick({
                nextArrow: '<button  class="vk-btn vk-arrow next"><i class="fa fa-chevron-right"></i></button>',
                prevArrow: '<button  class="vk-btn vk-arrow prev"><i class="fa fa-chevron-left"></i></button>',
            });
        }
        if (currentWidth < 992 && jQuery('.vk-slider-what-we-do.vk-filter-fix').length == 0) {
            if (jQuery('.vk-slider-what-we-do.slick-slider').length == 1) {
                jQuery('.vk-slider-what-we-do').slick('destroy');
            }

            jQuery('.vk-slider-what-we-do').addClass('vk-filter-fix');
            filterFix();

        }
    };

    var filterFix = function () {
        jQuery(listFilterFix.toString()).isotope({
            filter: '.first',
        });
        jQuery(buttonFilterFix)
            .on('click', 'li', function () {
                var filterValue = jQuery(this).attr('data-filter');
                jQuery(listFilterFix.toString()).isotope({
                    filter: filterValue,
                });

                return false;
            })
            .on('change', function () {
                /*get filter value from option value*/
                var filterValue = this.value;
                jQuery(listFilterFix.toString()).isotope({
                    filter: filterValue,

                });

                return false;
            });
    }
    var masonryLayout = function () {
        for (var i = 0; i < masonry_item.length; i++) {

            jQuery(masonry_item[i]).isotope({
                itemSelector: '.item',
                masonry: {
                    columnWidth: '.item',
                }
            });
        }

        /*filter items on button click*/
        jQuery(buttonFilterDefault)
            .on('click', 'li', function () {
                var filterValue = jQuery(this).attr('data-filter');
                jQuery(masonry_item.toString()).isotope({
                    filter: filterValue,
                });
                return false;
            })
            .on('change', function () {
                /*get filter value from option value*/
                var filterValue = this.value;
                jQuery(masonry_item.toString()).isotope({
                    filter: filterValue,

                });

                return false;
            });
    };

    var clickActive = function () {
        jQuery(buttonFilter).find('li:first-child').addClass('active');
        jQuery(buttonFilter).on('click', 'li', function (e) {

            jQuery(this).siblings('.active').removeClass('active');

            jQuery(this).addClass('active');

            return false;
        });
    };

    var _initInstances = function () {
        clickActive();
        masonryLayout();
        sliderFilter();
        filterFix();
        sliderResponsiveFilter();

    };

    return {
        init: function () {
            _initInstances();
        },

        responsive: function () {
            sliderResponsiveFilter();
        }
    };
}();

/*input file*/
var InputFile = function () {
    var _initInstances = function () {
        var inputs = document.querySelectorAll('.vk-input-file');
        Array.prototype.forEach.call(inputs, function (input) {
            var label = input.nextElementSibling,
                labelVal = label.innerHTML;

            input.addEventListener('change', function (e) {
                var fileName = '';
                if (this.files && this.files.length > 1)
                    fileName = ( this.getAttribute('data-multiple-caption') || '' ).replace('{count}', this.files.length);
                else
                    fileName = e.target.value.split('\\').pop();

                if (fileName)
                    label.querySelector('span').innerHTML = fileName;
                else
                    label.innerHTML = labelVal;
            });

            /*Firefox bug fix*/
            input.addEventListener('focus', function () {
                input.classList.add('has-focus');
            });
            input.addEventListener('blur', function () {
                input.classList.remove('has-focus');
            });
        });
    }
    return {
        init: function () {
            _initInstances();
        }
    };
}();

/*menu mobile*/
var MenuMobile = function () {
    var _initInstances = function () {

        jQuery('.vk-navbar-toggle.collapsed').on('click',function ($) {
            jQuery('#menu').slideToggle();
        });

        jQuery('#menu').slicknav({
            label: '.vk-navbar-toggle',
            duration: 500,
            prependTo: 'section'
        });
    };
    return {
        init: function () {
            _initInstances();
        }
    };
}();

/*mega menu*/
var MegaMenu = function () {

    var _initInstances = function () {

        jQuery('.sub-menu').addClass('vk-navbar-nav child');

        jQuery('.sub-menu').each(function () {

            if(jQuery(this).parent().hasClass('vk-mega-menu')){
                jQuery(this).addClass('vk-mega-menu');
            }
        });

    };

    return {
        init: function () {
            _initInstances();
        }
    };
}();

/*scroll up*/
var ScrollToTop = function () {

    var _initInstances = function () {
        jQuery('#btnscrollup').fadeOut();
        jQuery(window).scroll(function() {
            if(jQuery(this).scrollTop() != 0) {
                jQuery('#btnscrollup').fadeIn();
            } else {
                jQuery('#btnscrollup').fadeOut();
            }
        });
        jQuery('#btnscrollup').on('click', function(){
            jQuery('body,html').animate({scrollTop:0},800);
        });

    };

    return {
        init: function () {
            _initInstances();
        }
    };
}();

/*lightbox otion*/
var LightBox = function () {
    var _initInstances = function () {
        lightbox.option({
            disableScrolling: true,
            showImageNumberLabel: false,
            wrapAround: true,
            alwaysShowNavOnTouchDevices: true
        })
    };
    return {
        init: function () {
            _initInstances();
        }
    };
}();

/*price range*/
var PriceRange = function () {
    var _initInstances = function () {
        var slider_range = '#slider-range';
        var amount1 = '#amount1';
        var amount2 = '#amount2';
        jQuery(slider_range).slider({
            range: true,
            min: 0,
            max: 1000,
            values: [59, 799],
            slide: function (event, ui) {
                jQuery(amount1).val(ui.values[0]);
                jQuery(amount2).val(ui.values[1]);
            }
        });
        jQuery(amount1).val(jQuery(slider_range).slider("values", 0));
        jQuery(amount2).val(jQuery(slider_range).slider("values", 1));
    };

    return {
        init: function () {
            _initInstances();
        }
    };
}();

/*calculator quantity*/
var CalcQuantity = function () {
    var _initInstances = function () {
        jQuery(".quantity button").on("click", function () {
            var $button = jQuery(this);
            var oldValue = $button.parent().siblings().find("input").val();

            if ($button.text() == "+") {
                var newVal = parseFloat(oldValue) + 1;
            } else {
                // Don't allow decrementing below zero
                if (oldValue > 0) {
                    var newVal = parseFloat(oldValue) - 1;
                } else {
                    newVal = 0;
                }
            }

            $button.parent().siblings().find("input").val(newVal);

            return false;
        });
    };

    return {
        init: function () {
            _initInstances();
        }
    };
}();

var Tooltip = function () {
    var _initInstances = function () {
        jQuery('[data-toggle="tooltip"]').tooltip();
    }

    return {
        init: function () {
            _initInstances();
        }
    };
}();

var CustomTheme = function () {
    var wi = jQuery(window).width();
    var custom = function () {
        if (jQuery('.vk-home-dark').length) {
            jQuery('#scrollUp').addClass('inverse');
        }
        if (jQuery('.vk-header-left-menu').length) {
            jQuery('body').addClass('vk-left-menu');
        }
        if(wi > 991){
            if (jQuery('.vk-header-left-menu').length) {

                jQuery('#menu .child').prepend('<li class="back"> <i class="fa fa-angle-double-left"></i></li>');
                jQuery('#menu .vk-navbar-nav:not(.child)').on('click', 'li', function () {
                    console.log(jQuery(this));
                    jQuery(this).find('.child').fadeIn();
                    jQuery('#menu').css('transform', 'translateX(-100%)');

                    jQuery('.back').on('click', function () {
                        jQuery('#menu').css('transform', 'translateX(0%)');
                        jQuery(this).parent().fadeOut();
                        return false;
                    });
                });
            }
        }
        if (jQuery('.vk-home-one-page').length) {
            jQuery('body').addClass('vk-one-page');
        }

        jQuery("#navScroll2Id a").mPageScroll2id();

    }
    var customByDevice = function () {
        jQuery('.vk-one-page .section').css('min-height', jQuery(window).height());
    }
    var _initInstances = function () {
        custom();
    };

    return {
        init: function () {
            _initInstances();
            customByDevice();
        },
        responsive: function () {
            customByDevice();
        }
    };
}();
jQuery(window).on('load', function () {
    MasonryItem.init();
});

jQuery(window).resize(function () {
    MasonryItem.responsive();
    Slider.responsive();
    CustomTheme.responsive();

});

jQuery(document).ready(function () {
    jQuery('.vk-filter-fix .item:nth-child(1)').addClass('first');
    AnimationScrollPage.init();
    Slider.init();
    MenuMobile.init();
    InputFile.init();
    MegaMenu.init();
    ScrollToTop.init();
    LightBox.init();
    CustomTheme.init();
    PriceRange.init();
    CalcQuantity.init();
    Tooltip.init();
    jQuery('.vk-btn-go-back').on('click',function () {
        window.history.back();
    });
});
