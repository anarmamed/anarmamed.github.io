<section class="vk-content">

    <div class="vk-banner vk-background-image-3">
        <div class="vk-background-overlay vk-background-black-1 _80"></div>
        <div class="container wrapper">
            <div class="page-heading">
                <header class="entry-header">
                    <?php the_title('<h1 class="page-title">', '</h1>'); ?>
                </header><!-- .entry-header -->
            </div>
        </div>
    </div>
    <!--./vk-banner-->
    <div class="vk-breadcrumb">
        <nav class="container">
            <div class="">
                <ul>

                    <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html__('home', 'wicon'); ?></a>
                    </li>

                    <li class="active"><?php echo the_title(); ?></li>
                </ul>
            </div>
        </nav>
    </div>
    <!--./vk-breadcrumb-->