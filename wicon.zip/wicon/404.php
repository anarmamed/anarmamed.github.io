<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package wicon
 */

get_header();
$error_menu_right = get_theme_mod('error_menu_right');
?>
    <section class="vk-content">
        <div class="vk-banner vk-background-image-3">
            <div class="vk-background-overlay vk-background-black-1 _80"></div>
            <div class="container wrapper">
                <div class="page-heading">
                    <h1 class="page-title"><?php echo esc_html__('404', 'wicon'); ?></h1>
                </div>
            </div>
        </div>
        <!--./vk-banner-->
        <div class="vk-breadcrumb">
            <nav class="container">
                <?php get_template_part('template-parts/breadcrumbs'); ?>
            </nav>
        </div>
        <!--./vk-breadcrumb-->
        <div class="vk-page vk-page-404">
            <div class="container">
                <?php if (isset($error_menu_right) && $error_menu_right !== '0') :
                    echo '<div class="col-md-9 left">';
                else :
                    echo '<div class="col-md-12 err-full-width">';
                endif; ?>
                <div class="vk-img-frame">
                    <?php
                    if (!empty(get_theme_mod('background_404'))) :
                        ?>
                        <img class="img-responsive" src="<?php echo esc_url(get_theme_mod('background_404')); ?>"
                             alt="<?php esc_attr_e('404', 'wicon'); ?>">
                        <?php
                    else :
                        ?>
                        <img class="img-responsive"
                             src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/404.png'); ?>"
                             alt="<?php esc_attr_e('404', 'wicon'); ?>">
                        <?php
                    endif;
                    ?>
                </div>
                <div class="vk-search-form">
                    <div class="form-group">
                        <?php get_search_form(); ?>
                    </div>
                    <div class="vk-buttons">
                        <a href="#" class="vk-btn vk-btn-l text-uppercase vk-btn-go-back"><i class="fa fa-long-arrow-left"></i> <?php echo esc_html__('go back', 'wicon'); ?></a>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="vk-btn vk-btn-l vk-btn-default text-uppercase"><i class="fa fa-home"></i> <?php echo esc_html__('home page', 'wicon'); ?></a>
                    </div>
                </div>
            </div>
            <!-- ./left-->

            <?php
            if (isset($error_menu_right) && $error_menu_right !== '0') :
                echo '<div class="col-md-3 right">';
                wp_nav_menu(
                    array(
                        'menu' => $error_menu_right,
                        'container' => 'ul',
                        'menu_class' => 'vk-list vk-menu-right',
                    )
                );
                echo '</div>';
            endif;
            ?>

        </div>
        <!--./container-->
        </div>
        <!--./vk-page-->
    </section>

<?php
get_footer();

