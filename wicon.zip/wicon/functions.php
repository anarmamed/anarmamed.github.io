<?php
/**
 * wicon functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package wicon
 */
include_once 'inc/merlin-config.php';

if (!function_exists('is_plugin_active')) {
    require_once(ABSPATH . 'wp-admin/includes/plugin.php');
}

if (!function_exists('wp_get_current_user')) {
    require_once(ABSPATH . 'wp-includes/pluggable.php');
}

if (!class_exists('WP_Customize_Section')) {
    require_once(ABSPATH . 'wp-includes/class-wp-customize-section.php');
}



if (!function_exists('wicon_setup')) :
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which
     * runs before the init hook. The init hook is too late for some features, such
     * as indicating support for post thumbnails.
     */
    function wicon_setup()
    {
        /*
         * Make theme available for translation.
         * Translations can be filed in the /languages/ directory.
         * If you're building a theme based on wicon, use a find and replace
         * to change 'wicon' to the name of your theme in all the template files.
         */
        load_theme_textdomain('wicon', get_template_directory() . '/languages');

        // Add default posts and comments RSS feed links to head.
        add_theme_support('automatic-feed-links');

        /*
         * Let WordPress manage the document title.
         * By adding theme support, we declare that this theme does not use a
         * hard-coded <title> tag in the document head, and expect WordPress to
         * provide it for us.
         */
        add_theme_support('title-tag');

        /*
         * Enable support for Post Thumbnails on posts and pages.
         *
         * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
         */
        add_theme_support('post-thumbnails');

        add_image_size('wicon-blog-thumb', 600, 450, array('center', 'center'));

        // This theme uses wp_nav_menu() in one location.
        register_nav_menus(array(
            'primary' => esc_html__('Primary', 'wicon'),
        ));

        /*
         * Switch default core markup for search form, comment form, and comments
         * to output valid HTML5.
         */
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ));

        // Set up the WordPress core custom background feature.
        add_theme_support('custom-background', apply_filters('wicon_custom_background_args', array(
            'default-color' => 'ffffff',
            'default-image' => '',
        )));

        // Add theme support for selective refresh for widgets.
        add_theme_support('customize-selective-refresh-widgets');

        // Add support for editor styles.
        add_theme_support( 'editor-styles' );

        // Enqueue editor styles.
        add_editor_style( 'style-editor.css' );


    }
endif;
add_action('after_setup_theme', 'wicon_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function wicon_content_width()
{
    $GLOBALS['content_width'] = apply_filters('wicon_content_width', 640);
}

add_action('after_setup_theme', 'wicon_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function wicon_widgets_init()
{
    register_sidebar(array(
        'name' => esc_html__('Sidebar', 'wicon'),
        'id' => 'sidebar-1',
        'description' => esc_html__('Add widgets here.', 'wicon'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => 'Sidebar Shop',
        'id' => 'sidebar-shop',
        'description' => 'Add widgets here',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>'
    ));
}

add_action('widgets_init', 'wicon_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function wicon_scripts()
{
    wp_enqueue_style('wicon', get_stylesheet_uri());

    wp_enqueue_script('wicon-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true);

    wp_enqueue_script('wicon-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}

add_action('wp_enqueue_scripts', 'wicon_scripts');

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
    require get_template_directory() . '/inc/jetpack.php';
}


function wicon_styles()
{
    wp_enqueue_style('wicon-shop', get_template_directory_uri() . '/assets/css/wicon/shop.css', false, '1.0');
    wp_enqueue_style('transfonter', get_template_directory_uri() . '/assets/plugin/fonts/transfonter/fonts.css', 'all');
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/plugin/fonts/font-awesome/css/font-awesome.min.css', 'all');
    wp_enqueue_style('font-awesome5', get_template_directory_uri() . '/assets/fonts/fa5/all.css', 'all');
    wp_enqueue_style('themify-icons', get_template_directory_uri() . '/assets/plugin/fonts/themify/themify-icons.css', 'all');
    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/vendors/bootstrap/css/bootstrap.min.css', 'all');
    wp_enqueue_style('animsition', get_template_directory_uri() . '/assets/vendors/animsition/css/animsition.min.css', 'all');
    wp_enqueue_style('lightbox', get_template_directory_uri() . '/assets/vendors/lightbox/css/lightbox.min.css', 'all');
    wp_enqueue_style('animate', get_template_directory_uri() . '/assets/css/animate.min.css', 'all');
    wp_enqueue_style('flaticon', get_template_directory_uri() . '/assets/plugin/fonts/platicon/font/flaticon.css', 'all');
    wp_enqueue_style('fonts-icomoon', get_template_directory_uri() . '/assets/fonts/icomoon/icon.css', 'all');
    wp_enqueue_style('slick', get_template_directory_uri() . '/assets/vendors/slick/slick.css', 'all');
    wp_enqueue_style('wicon-main', get_template_directory_uri() . '/assets/css/wicon-main.css', 'all');
    wp_enqueue_style( 'magnific-popup', get_template_directory_uri() . '/assets/vendors/magnific-popup/magnific-popup.css' );

    if( !class_exists( 'Univercore' ) ){

        $protocol = is_ssl() ? 'https' : 'http';

        $wicon_df_body_fonts = add_query_arg(
            array(
                'family' => urldecode( 'Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i' ),
                'subset' => urlencode( 'latin,latin-ext' ),
            ),
            "{$protocol}://fonts.googleapis.com/css"
        );
        wp_enqueue_style( 'body-google-fonts', esc_url( $wicon_df_body_fonts ), false );

    }

}

add_action('wp_enqueue_scripts', 'wicon_styles');


/*script*/
function wicon_script()
{

    wp_enqueue_script('jquery-ui-slider');
    wp_enqueue_script('masonry');

    wp_enqueue_script('modernizr', get_template_directory_uri() . '/assets/plugin/modernizr.js', array('jquery'), true);

    wp_enqueue_script('animsition', get_template_directory_uri() . '/assets/vendors/animsition/js/animsition.min.js', array('jquery'), true);
    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/vendors/bootstrap/js/bootstrap.min.js', array('jquery'), true);
    wp_enqueue_script('isotope', get_template_directory_uri() . '/assets/vendors/isotope.pkgd.min.js', array('jquery'), true);
    wp_enqueue_script('page-scroll-to-id', get_template_directory_uri() . '/assets/vendors/page-scroll-to-id.min.js', array('jquery'), true);
    wp_enqueue_script('slicknav', get_template_directory_uri() . '/assets/vendors/slicknav/jquery.slicknav.js', array('jquery'), true);
    wp_enqueue_script('waypoints', get_template_directory_uri() . '/assets/vendors/waypoints/jquery.waypoints.min.js', array('jquery'), true);
    wp_enqueue_script('lightbox', get_template_directory_uri() . '/assets/vendors/lightbox/js/lightbox.min.js', array('jquery'), true);
    wp_enqueue_script('slick', get_template_directory_uri() . '/assets/vendors/slick/slick.min.js', array('jquery'), true);
    wp_enqueue_script('animateNumber', get_template_directory_uri() . '/assets/vendors/jquery.animateNumber.min.js', array('jquery'), '0.0.14' , true);

    wp_enqueue_script('wicon-main', get_template_directory_uri() . '/assets/plugin/main.js', array('jquery'), true);

    wp_enqueue_script( 'magnific-popup', get_template_directory_uri() . '/assets/vendors/magnific-popup/jquery-magnific-popup.min.js', array('jquery'),  '', true );

    wp_enqueue_script( 'wicon-quickview',  get_template_directory_uri() . '/js/wicon-quickview.js', array( 'jquery' ), '', true );
    wp_localize_script( 'wicon-quickview', 'wicon_quickview', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'ajax_nonce' => wp_create_nonce('wicon-quickview'),
    ));
}

add_action('wp_enqueue_scripts', 'wicon_script');

add_action('woocommerce_after_shop_loop_item', 'wicon_quickview_button',9);

add_action( 'wp_ajax_wicon_quickview', 'wicon_quickview'  );
add_action( 'wp_ajax_nopriv_wicon_quickview', 'wicon_quickview' );

add_action( 'wicon_wc_product_summary_quickview', 'woocommerce_template_single_rating', 11 );
add_action( 'wicon_wc_product_summary_quickview', 'woocommerce_template_single_price', 10 );
add_action( 'wicon_wc_product_summary_quickview', 'woocommerce_template_single_excerpt', 20 );
add_action( 'wicon_wc_product_summary_quickview', 'woocommerce_template_single_add_to_cart', 30 );

add_filter('loop_shop_columns', 'wicon_loop_columns' );
function wicon_loop_columns() {
    $column = get_theme_mod('column_shop','3' );
    if($column == '2'){
        return 2;
    }elseif($column == '1'){
        return 1;
    }
    elseif($column == '4'){
        return 4;
    }elseif($column == '3'){
        return 3;
    }
    else{
        return 4;
    }

}

add_filter( 'woocommerce_output_related_products_args', 'wicon_related_products_args' );
function wicon_related_products_args( $args ) {
    $column_related = get_theme_mod('column_shop_related','4' );
    $args['posts_per_page'] = $column_related;
    $args['columns'] = $column_related;
    return $args;
}

add_filter( 'woocommerce_upsell_display_args', 'wicon_wc_change_number_upsell_products', 20 );
function wicon_wc_change_number_upsell_products( $args ) {
    $column_upsell = get_theme_mod('column_shop_related','4' );
    $args['posts_per_page'] = $column_upsell;
    $args['columns'] = $column_upsell;
    return $args;
}

function wicon_quickview() {

    check_ajax_referer( 'wicon-quickview', 'security' );

    global $post, $product, $woocommerce;
    $wicon_prod_id = $_POST["productid"];
    $post = get_post( $wicon_prod_id );
    $product = wc_get_product( $wicon_prod_id );
    
    wc_get_template( 'wicon-quickview.php' );

    die();
}


function wicon_quickview_button(){
    global $post, $product, $woocommerce;
    echo '<a href="#" class="wicon-quick-view" data-id="'.$post->ID.'"><i class="fa fa-eye" aria-hidden="true"></i></a>';
}

/*end quickview*/

add_filter('wp_nav_menu_items', 'wicon_add_search_to_nav', 10, 2);

function wicon_add_search_to_nav($items, $args)
{
    if (get_theme_mod('layout_header') === 'header5') {
        $items .= "";
    }
    return $items;

}
add_theme_support( 'woocommerce' );
add_theme_support('wc-product-gallery-zoom');
add_theme_support('wc-product-gallery-lightbox');
add_theme_support('wc-product-gallery-slider');

function wicon_get_pagination_links()
{
    global $wp_query;
    $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;
    $big = 999999999;

    $pagination =  paginate_links(array(
        'base' => @add_query_arg('paged', '%#%'),
        'format' => '?paged=%#%',
        'current' => $current,
        'total' => $wp_query->max_num_pages,
        'prev_next' => True,
        'prev_text' => esc_html__('Prev', 'wicon'),
        'next_text' => esc_html__('Next', 'wicon')
    ));
    if ( $pagination ) {
        return '<div class="univer-pagination">'. $pagination . '</div>';
    }
}
add_action( 'woocommerce_after_shop_loop_item', 'wicon_wc_after_shop_wrap_open', 6 );
function wicon_wc_after_shop_wrap_open(){
    echo '<div class="wicon-warp-after-shop-item">';
}
add_action( 'woocommerce_after_shop_loop_item', 'wicon_wc_after_shop_wrap_close', 11 );
function wicon_wc_after_shop_wrap_close(){
    echo '</div>';
}
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );

add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_price', 7 );
add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_rating', 8 );

/*WooCommerce minicart*/
add_filter('woocommerce_add_to_cart_fragments', 'wicon_woocommerce_header_add_to_cart_fragment');

function wicon_woocommerce_header_add_to_cart_fragment($fragments)
{
    global $woocommerce;
    ob_start();
    ?>
    <span class="number-item"><?php echo esc_attr($woocommerce->cart->get_cart_contents_count()); ?></span>
    <?php
    $fragments['.number-item'] = ob_get_clean();
    return $fragments;
}

add_filter('woocommerce_add_to_cart_fragments', 'wicon_woocommerce_header_mini_cart_fragment');

function wicon_woocommerce_header_mini_cart_fragment($fragments)
{
    global $woocommerce;
    ob_start();
    ?>
    <div class="vk-table woo-mini-cart">
        <?php
        if ($woocommerce->cart->get_cart_contents_count() > 0) {
            ?>
            <ul class="vk-table-row">
                <li class="vk-table-data"><?php echo esc_html__('product', 'wicon'); ?></li>
            </ul>
            <?php
        }

        woocommerce_mini_cart(); ?>
    </div>
    <?php
    $fragments['.woo-mini-cart'] = ob_get_clean();
    return $fragments;

}


function wicon_kirki_demo_configuration_sample_styling($config)
{
    return wp_parse_args(array(
        'logo_image' => get_template_directory_uri() . '/assets/images/logo2.png',
        'description' => esc_attr__('Design by Ava-Themes 2018', 'wicon'),
        'color_accent' => '#0091EA',
        'color_back' => '#FFFFFF',
    ), $config);
}

add_filter('kirki_config', 'wicon_kirki_demo_configuration_sample_styling');


//control slider gallery single product
add_filter('woocommerce_single_product_carousel_options', 'wicon_ud_update_woo_flexslider_options');

function wicon_ud_update_woo_flexslider_options($options)
{
    $options['directionNav'] = true;
    return $options;
}

/**
 * Recomend plugins via TGM activation class
 */

require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';
global $tgmpa;
$tgmpa = isset($GLOBALS['tgmpa']) ? $GLOBALS['tgmpa'] : TGM_Plugin_Activation::get_instance();

add_action('tgmpa_register', 'wicon_register_required_plugins');
add_action('wp_ajax_uni_install_framework', 'ajax_install_framework');
add_action('wp_ajax_uni_active_framework', 'ajax_active_framework');

add_action('admin_enqueue_scripts', 'redirect_merlin' );

add_action('after_switch_theme', 'wicon_setup_del_options' );

function redirect_merlin() {
    wp_register_script( 'redirect-page', get_template_directory_uri() . '/assets/plugin/admin/redirect-page.js', array('jquery'), time() );

    $translation_array = array(
        'import_merlin_url' => admin_url( 'themes.php?page=merlin' )
    );
    wp_localize_script( 'redirect-page', 'object_merlin', $translation_array );

    wp_enqueue_script( 'redirect-page' );
}

function wicon_setup_del_options() {
    delete_option( 'merlin_wicon_redirected' );
}

/**
 * Register the required plugins for this theme.
 * This function is hooked into `tgmpa_register`, which is fired on the WP `init` action on priority 10.
 */

function wicon_register_required_plugins()
{

    /**
     * Array of plugin arrays. Required keys are name and slug.
     * If the source is NOT from the .org repo, then source is also required.
     */
    $plugins = array(
        array(
            'name' => esc_html__('Univercore', 'wicon'),
            'slug' => 'univercore',
            'source' => get_template_directory_uri() . '/inc/import-files/plugins/univercore.zip',
            'required' => false,
            'force_activation' => false,
            'force_deactivation' => false,
        ),

    );
    $config = array(
        'id' => 'wicon',
        'default_path' => '',                      // Default absolute path to pre-packaged plugins.
        'menu' => 'tgmpa-install-plugins', // Menu slug.
        'has_notices' => true,                    // Show admin notices or not.
        'dismissable' => true,                    // If false, a user cannot dismiss the nag message.
        'dismiss_msg' => '',                      // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => false,                   // Automatically activate plugins after installation or not.
        'message' => '',                      // Message to output right before the plugins table.

    );

    tgmpa($plugins, $config);
}

function ajax_install_framework()
{
    if (!check_ajax_referer('uni_nonce', 'wpnonce') || empty($_POST['slug'])) {
        exit(0);
    }
    $json = array();
    $tgmpa_url = $this->$tgmpa->get_tgmpa_url();
    if ($_POST['slug'] === 'install') {
        $json = array(
            'url' => $tgmpa_url,
            'plugin' => array('univercore'),
            'tgmpa-page' => $this->$tgmpa->menu,
            '_wpnonce' => wp_create_nonce('bulk-plugins'),
            'action' => 'tgmpa-bulk-install',
            'action2' => -1,
            'message' => esc_html__('Installing', 'wicon'),
        );
    } elseif ($_POST['slug'] === 'active') {
        $json = array(
            'url' => $tgmpa_url,
            'plugin' => array('univercore'),
            'tgmpa-page' => $this->$tgmpa->menu,
            '_wpnonce' => wp_create_nonce('bulk-plugins'),
            'action' => 'tgmpa-bulk-activate',
            'action2' => -1,
            'message' => esc_html__('Activating', 'wicon'),
        );
    }

    if ($json) {
        wp_send_json($json);
    } else {
        wp_send_json(array('done' => 1, 'message' => esc_html__('Success', 'wicon')));
    }

    exit;
}
/*e-import-demo*/

function wicon_class_active_sidebar(){
    $class_entry_sidebar = "";
    if ( !is_active_sidebar( 'sidebar-1' ) ) {
        $class_entry_sidebar = 'wicon-e-sidebar';
    }
    return $class_entry_sidebar;
}

remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
function wicon_woo_breadcrumbs(){
    $wicon_output = '';
    $args = array(
        'delimiter'   => '',
        'wrap_before' => '<div class="vk-breadcrumb"><nav class="container"><ul>',
        'wrap_after'  => '</ul></nav></div>',
        'before'      => '<li class="item">',
        'after'       => '</li>',

    ) ;
    $wicon_output .= woocommerce_breadcrumb($args);

    return $wicon_output;
}

add_filter( 'the_content_more_link', 'wicon_modify_read_more_link'  );
function wicon_modify_read_more_link() {
    return '<a class="wicon-more-link" href="' . esc_url(get_permalink()) . '">'. esc_html__('Continue reading...', 'wicon' ) .'</a>';
}

/*custom option css*/
function get_embed_style()
{
    global $post, $woocommerce;
    $page_id = get_the_ID();
    if ($page_id) {
        $meta_header_style = get_post_meta($page_id, 'custom-header', true);
        $page_meta_header_bg_color = get_post_meta($page_id, 'meta-header-bg', true);
    }
    
    $header2_bg = get_theme_mod('layout_background_header2','#f4f4f4');
    $header2_txtcolor = get_theme_mod('header2_txtcolor','#333333');
    $header4_bg = get_theme_mod('layout_background_header4','#ffffff');
    $primary_color = get_theme_mod('primary_color','#FFC000');
    $secondary_color = get_theme_mod('wicon_secondary_color','#FFC000');
    $wicon_link_hover_color = get_theme_mod('wicon_link_hover_color','#FFC000');

    $back_to_top_bg = get_theme_mod('back_to_top_bg','#a1a1a1');
    $back_to_top_color = get_theme_mod('back_to_top_color','#ffffff');
    $back_to_top_bg_hover = get_theme_mod('back_to_top_bg_hover','#FFC000');
    $back_to_top_color_hover = get_theme_mod('back_to_top_color_hover','#434343');
    
    $footer_bg_color = get_theme_mod('footer_bg_color','#2E3841');
    $color_footer_style1 = get_theme_mod('color_footer_style1','#ffc000');
    $color_footer_style3 = get_theme_mod('color_footer_style3','#b7b7b7');
    $mobile_header_bg = get_theme_mod('mobile_header_bg','#222222');
    
    $wicon_btn_bg_color = get_theme_mod('wicon_btn_bg_color','#FFC000');
    $wicon_btn_color = get_theme_mod('wicon_btn_color','#ffffff');
    $wicon_btn_border_color = get_theme_mod('wicon_btn_border_color','#FFC000');
    $wicon_btn_bg_color_hover = get_theme_mod('wicon_btn_bg_color_hover','#ffffff');
    $wicon_btn_color_hover = get_theme_mod('wicon_btn_color_hover','#FFC000');
    $wicon_btn_border_color_hover = get_theme_mod('wicon_btn_border_color_hover','#FFC000');
    $color_header_lux_color = get_theme_mod('color_header_lux_color','#161E26');
    $color_header_lux_bg = get_theme_mod('color_header_lux_bg','#ffffff');    

    $css = "";

    if (is_page() && $meta_header_style == 'Header 1' && $page_meta_header_bg_color !== '' ) {
        $css .= '.vk-header1 {background-color:' . $page_meta_header_bg_color . ';  }';
    }
    
    $css .= '.vk-header2{background-color:'.$header2_bg.';  }';
    $css .= '.vk-header4{background-color:'.$header4_bg.';  }';
    $css .= '.vk-header-left-menu .btn-search,.vk-header-left-menu .vk-navbar .search-shopcart-button .shopping-cart{color:'.$header2_txtcolor.';  }';
    $css .= '#btnscrollup{background-color:'.$back_to_top_bg.';color:'.$back_to_top_color.';  }';
    $css .= '#btnscrollup:hover{background-color:'.$back_to_top_bg_hover.';color:'.$back_to_top_color_hover.';  }';
    $css .= '.h-luxyry-main{background-color:'.$color_header_lux_bg.'; color:'.$color_header_lux_color.';  }';
    $css .= '.h-luxyry-main .h-shopping-cart, .h-luxyry-menu > .navbar-toggle{color:'.$color_header_lux_color.';  }';
    
    $css .= '.vk-btn-icon.vk-btn-default:hover, .vk-btn-icon.vk-btn-default:focus{-webkit-box-shadow: inset 0 0 0 2px '.$primary_color.';-moz-box-shadow: inset 0 0 0 2px '.$primary_color.';box-shadow: inset 0 0 0 2px '.$primary_color.';}';
    $css .= '.vk-home-blog-list.uni-wicon-slider .vk-btn,.color-primary,.vk-btn-transparent,
    .woocommerce nav.woocommerce-pagination ul li a:focus, .uni-service-style2 .btn-read,
    .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current,
    .vk-project-grid-item .vk-title a:hover, .vk-project-grid-item .vk-title a:focus,.vk-filter li.active,.vk-filter li:hover,
    .unielement-project-tab .tab_title.selected a,.vk-text-color-yellow-1{color:'.$primary_color.';  }';
    $css .= '.unielement-project-tab.ls-luxury .tab_title.selected a:after,.vk-navbar-right-fixed .vk-nav-scroll-to-id li a.mPS2id-highlight:before, 
    .vk-navbar-right-fixed .vk-nav-scroll-to-id li a:hover:before, .vk-navbar-right-fixed .vk-nav-scroll-to-id li a:focus:before,
    .wpt-tab-header .vk-heading:before,.wpt-tab-header .vk-heading:after,.h-bottom,
    .vk-heading-border > span:after, .vk-heading-border > span:before{background-color:'.$primary_color.';  }';

    $css .= '.uni-testimonial-layout5 .vk-img-frame img,.vk-navbar-right-fixed .vk-nav-scroll-to-id li a.mPS2id-highlight:after, 
    .vk-navbar-right-fixed .vk-nav-scroll-to-id li a:hover:after, .vk-navbar-right-fixed .vk-nav-scroll-to-id li a:focus:after,
    .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, 
    .woocommerce nav.woocommerce-pagination ul li span.current{border-color:'.$primary_color.';  }';

    $css .= '.itemfive,.img-about-default .vk-img-frame:before{border-top-color:'.$primary_color.';  }';
    $css .= '.service-style2-img:before,.img-about-default .vk-img-frame:before{border-right-color:'.$primary_color.';  }';
    $css .= '.blog-luxury .brief-post{border-left-color:'.$primary_color.';  }';
    $css .= '.service-style2-img:before{border-bottom-color:'.$primary_color.';  }';
    $css .= '.vk-footer {background-color:' . $footer_bg_color . ';  }';

    $css .= '@media screen and (max-width: 991px){.vk-header-home .vk-navbar {background-color:' . $mobile_header_bg . ';}}';
    $css .= '.widget .vk-social-link li a:hover,.vk-footer.footer-layout-1 .widget_nav_menu li::before,.vk-footer .widget_nav_menu li:hover::before,.vk-footer .widget_nav_menu li a:hover,.vk-footer .vk-office li i {color:' . $color_footer_style1 . ';}';    
    $css .= '.comment-single a:hover, .page-links a:hover, a.page-numbers:hover{background-color:'.$secondary_color.';  }';
    $css .= '.comment-single a:hover, .page-links a:hover, a.page-numbers:hover,.comment-single span.current, span.post-page-numbers.current, span.page-numbers.current{border-color:'.$secondary_color.';  }';
    $css .= '.comment-single span.current, span.post-page-numbers.current, span.page-numbers.current{color:'.$secondary_color.';  }';

    $css .= '.widget .vk-social-link li a,.vk-footer .vk-office li,.vk-footer .widget_nav_menu li a,.vk-footer p{color:'.$color_footer_style3.';  }';
    
    $css .= '.widget.widget_nav_menu .vk-navbar-nav.child li a:not(.slicknav_item):hover, .widget.widget_recent_entries ul li a:hover, .widget.widget_nav_menu ul li a:hover, .widget.widget_meta ul li a:hover, .widget.widget_pages ul li a:hover, .widget.widget_categories ul li a:hover, .widget.widget_archive ul li a:hover,.entry-content a:hover,.wp-block-button__link:active, .wp-block-button__link:focus, .wp-block-button__link:hover, a:hover, a:focus,.vk-blog-grid .blog-content .content-box .content h4:hover,.vk-btn-readmore:hover, .vk-btn-readmore:focus{color:'.$wicon_link_hover_color.';  }';
    $css .= '.tagcloud a:hover, .tagcloud a:focus,.vk-blog-wrapper .vk-tag:hover a {background-color:' . $wicon_link_hover_color . ';  }';
    $css .= '.woocommerce-widget-layered-nav ul li:hover,.widget.widget_recent_entries ul li:hover,.widget.widget_nav_menu ul li:hover,.widget.widget_meta ul li:hover,.widget.widget_pages ul li:hover,.widget.widget_categories ul li:hover,.widget.widget_archive ul li:hover {border-color:' . $wicon_link_hover_color . ';  }';    
    
    $css .= '.uni-about-img a.btn-read-more,.vk-header .shopping-cart-list p.woocommerce-mini-cart__buttons.buttons a,button, input[type="button"],  input[type="reset"], input[type="submit"],.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,.woocommerce div.product form.cart .button,a.wicon-more-link, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button {background-color:' . $wicon_btn_bg_color . ';  }';
    $css .= '.uni-about-img a.btn-read-more,.vk-header .shopping-cart-list p.woocommerce-mini-cart__buttons.buttons a,button, input[type="button"],  input[type="reset"], input[type="submit"],.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,.woocommerce div.product form.cart .button,a.wicon-more-link, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button {color:' . $wicon_btn_color . ';  }';
    $css .= '.uni-about-img a.btn-read-more,.vk-header .shopping-cart-list p.woocommerce-mini-cart__buttons.buttons a,button, input[type="button"],  input[type="reset"], input[type="submit"],.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,.woocommerce div.product form.cart .button,a.wicon-more-link, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button {border-style: solid;border-width: 1px;border-color:' . $wicon_btn_border_color . ';  }';
    
    $css .= '.uni-about-img a.btn-read-more:hover,.vk-header .shopping-cart-list p.woocommerce-mini-cart__buttons.buttons a:hover,button:hover, button:focus, input[type="button"]:hover, input[type="button"]:focus, input[type="reset"]:hover, input[type="reset"]:focus, input[type="submit"]:hover, input[type="submit"]:focus,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.woocommerce div.product form.cart .button:hover,a.wicon-more-link:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover {background-color:' . $wicon_btn_bg_color_hover . ';  }';
    $css .= '.uni-about-img a.btn-read-more:hover,.vk-header .shopping-cart-list p.woocommerce-mini-cart__buttons.buttons a:hover,button:hover, button:focus, input[type="button"]:hover, input[type="button"]:focus, input[type="reset"]:hover, input[type="reset"]:focus, input[type="submit"]:hover, input[type="submit"]:focus,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.woocommerce div.product form.cart .button:hover,a.wicon-more-link:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover {color:' . $wicon_btn_color_hover . ';  }';
    $css .= '.uni-about-img a.btn-read-more:hover,.vk-header .shopping-cart-list p.woocommerce-mini-cart__buttons.buttons a:hover,button:hover, button:focus, input[type="button"]:hover, input[type="button"]:focus, input[type="reset"]:hover, input[type="reset"]:focus, input[type="submit"]:hover, input[type="submit"]:focus,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.woocommerce div.product form.cart .button:hover,a.wicon-more-link:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover {border-color:' . $wicon_btn_border_color_hover . ';  }';

    return $css;

}
function wicon_print_embed_style()
{
    $style = get_embed_style();

    $style = preg_replace('#/\*.*?\*/#s', '', $style);
    $style = preg_replace('/\s*([{}|:;,])\s+/', '$1', $style);
    $style = preg_replace('/\s\s+(.*)/', '$1', $style);

    wp_register_style('z_wicon_front_style', false);
    wp_enqueue_style('z_wicon_front_style');
    wp_add_inline_style('z_wicon_front_style', $style);
}

add_action('wp_enqueue_scripts', 'wicon_print_embed_style', 9999);

function wicon_get_related_project($id)
{
    global $relatedcatargs;
    $limit_post = 3;
    $my_query = '';
    $rel_catnames = array();
    $post_cats = get_the_terms($id, 'project_cats');
    if ($post_cats && !is_wp_error($post_cats)) {
            foreach ($post_cats as $post_cat) {
                $rel_catnames[] = $post_cat->slug;
            }

            $relatedcatargs = array(
                'post_type' => 'pt_project',
                'post__not_in' => array($id),
                'posts_per_page' => $limit_post,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'project_cats',
                        'field' => 'slug',
                        'terms' => $rel_catnames,
                    )
                ),
            );
            $my_query = new WP_Query($relatedcatargs);
    }

    if ($my_query !== '' && $my_query->have_posts()) :
        ?>
        <div class="wicon-related-project">
            <div class="container">
                <h2 class="title-style firstword"><?php echo esc_html__('Related Project', 'wicon'); ?></h2>
                <div class="row">
                    <?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="vk-project vk-project-grid-item">
                                <?php
                                if (has_post_thumbnail()) :?>
                                    <div class="vk-img-frame">
                                        <?php
                                        echo '<a href="' . esc_url(get_permalink()) . '"  class="img-responsive">';
                                        the_post_thumbnail('wicon-blog-thumb');
                                        echo '</a>';
                                        ?>
                                    </div>
                                <?php endif; ?>
                                    <div class="content-hidden">

                                        <?php the_title('<h4 class="text-uppercase"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h4>'); ?>
                                    </div>

                            </div>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </div>
    <?php
    endif;

}
